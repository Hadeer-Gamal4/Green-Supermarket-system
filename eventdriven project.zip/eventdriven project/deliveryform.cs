﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace eventdriven_project
{
    public partial class deliveryform : Form
    {
        public deliveryform()
        {
            InitializeComponent();
        }

        //taking object from the oop class we already made

        deliveryclass c = new deliveryclass();

        private void donebutton_Click(object sender, EventArgs e)
        {
            try
            {
                if (Fnametxtbox.Text.Trim() == string.Empty || Lnametxtbox.Text.Trim() == String.Empty || addresstxtbox.Text.Trim() == String.Empty)
                {
                    MessageBox.Show("Sorry,All fields should contain an answer");
                    return;
                }
                //validating first name,last name to accept only upper or lower cases no number

                
                var haslowerchar1 = new Regex(@"[a-z]+");
                var hasupperchar2 = new Regex(@"[A-Z]+");
                var haslowerchar2 = new Regex(@"[a-z]+");
                var hasnumber1 = new Regex(@"[1-9]+");
                var hasnumber2= new Regex(@"[1-9]+");


                if ( !haslowerchar1.IsMatch(Fnametxtbox.Text) ||  !haslowerchar2.IsMatch(Lnametxtbox.Text) || hasnumber1.IsMatch(Fnametxtbox.Text) || hasnumber2.IsMatch(Lnametxtbox.Text))
                {
                    MessageBox.Show("Sorry,You entered Firstname or Last Name wrong");
                    return;
                }
                else
                {
                   
                    c.fname = Fnametxtbox.Text;
                    c.lname = Lnametxtbox.Text;
                    c.address = addresstxtbox.Text;
                }

                bool sucess = c.Insert(c);
                if (sucess == true)
                {
                    last f1 = new last();
                    f1.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Sorry,Please try again");

                }
          
            }
            catch
            {
                MessageBox.Show("sorry,something went wrong");
            }


            }

        private void exitlabel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
