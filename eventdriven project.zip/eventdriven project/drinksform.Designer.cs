﻿namespace eventdriven_project
{
    partial class drinksform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(drinksform));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.backlabel = new System.Windows.Forms.Label();
            this.nextlabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.exitlabel = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.water_namelabel = new System.Windows.Forms.Label();
            this.cocacola_namelabel = new System.Windows.Forms.Label();
            this.pepsi_namelabel = new System.Windows.Forms.Label();
            this.zabado_namelabel = new System.Windows.Forms.Label();
            this.Redbull_namelabel = new System.Windows.Forms.Label();
            this.tropicana_namelabel = new System.Windows.Forms.Label();
            this.water_pricelabel = new System.Windows.Forms.Label();
            this.cocacola_pricelabel = new System.Windows.Forms.Label();
            this.pepsi_labelprice = new System.Windows.Forms.Label();
            this.zabado_pricelabel = new System.Windows.Forms.Label();
            this.Redbull_pricelabel = new System.Windows.Forms.Label();
            this.tropicana_pricelabel = new System.Windows.Forms.Label();
            this.add_water = new System.Windows.Forms.Button();
            this.add_cocacola = new System.Windows.Forms.Button();
            this.add_pepsi = new System.Windows.Forms.Button();
            this.add_zabado = new System.Windows.Forms.Button();
            this.add_redbull = new System.Windows.Forms.Button();
            this.add_tropicana = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // backlabel
            // 
            this.backlabel.AutoSize = true;
            this.backlabel.Font = new System.Drawing.Font("Bookman Old Style", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backlabel.Location = new System.Drawing.Point(307, 31);
            this.backlabel.Name = "backlabel";
            this.backlabel.Size = new System.Drawing.Size(49, 20);
            this.backlabel.TabIndex = 36;
            this.backlabel.Text = "<<<<";
            this.backlabel.Click += new System.EventHandler(this.backlabel_Click);
            // 
            // nextlabel
            // 
            this.nextlabel.AutoSize = true;
            this.nextlabel.Font = new System.Drawing.Font("Bookman Old Style", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nextlabel.Location = new System.Drawing.Point(932, 31);
            this.nextlabel.Name = "nextlabel";
            this.nextlabel.Size = new System.Drawing.Size(49, 20);
            this.nextlabel.TabIndex = 37;
            this.nextlabel.Text = ">>>>";
            this.nextlabel.Click += new System.EventHandler(this.nextlabel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(497, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(281, 41);
            this.label1.TabIndex = 38;
            this.label1.Text = "Drinks Products\r\n";
            // 
            // exitlabel
            // 
            this.exitlabel.AutoSize = true;
            this.exitlabel.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitlabel.Location = new System.Drawing.Point(1291, 1);
            this.exitlabel.Name = "exitlabel";
            this.exitlabel.Size = new System.Drawing.Size(27, 28);
            this.exitlabel.TabIndex = 39;
            this.exitlabel.Text = "x";
            this.exitlabel.Click += new System.EventHandler(this.exitlabel_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(175, 102);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(203, 152);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 40;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(545, 102);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(203, 152);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 41;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(936, 102);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(203, 152);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 42;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(175, 432);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(203, 151);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 43;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(545, 432);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(203, 151);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 44;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(936, 432);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(203, 151);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 45;
            this.pictureBox7.TabStop = false;
            // 
            // water_namelabel
            // 
            this.water_namelabel.AutoSize = true;
            this.water_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.water_namelabel.Location = new System.Drawing.Point(237, 257);
            this.water_namelabel.Name = "water_namelabel";
            this.water_namelabel.Size = new System.Drawing.Size(92, 33);
            this.water_namelabel.TabIndex = 47;
            this.water_namelabel.Text = "Name";
            // 
            // cocacola_namelabel
            // 
            this.cocacola_namelabel.AutoSize = true;
            this.cocacola_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cocacola_namelabel.Location = new System.Drawing.Point(599, 257);
            this.cocacola_namelabel.Name = "cocacola_namelabel";
            this.cocacola_namelabel.Size = new System.Drawing.Size(92, 33);
            this.cocacola_namelabel.TabIndex = 48;
            this.cocacola_namelabel.Text = "Name";
            // 
            // pepsi_namelabel
            // 
            this.pepsi_namelabel.AutoSize = true;
            this.pepsi_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pepsi_namelabel.Location = new System.Drawing.Point(996, 257);
            this.pepsi_namelabel.Name = "pepsi_namelabel";
            this.pepsi_namelabel.Size = new System.Drawing.Size(92, 33);
            this.pepsi_namelabel.TabIndex = 49;
            this.pepsi_namelabel.Text = "Name";
            // 
            // zabado_namelabel
            // 
            this.zabado_namelabel.AutoSize = true;
            this.zabado_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zabado_namelabel.Location = new System.Drawing.Point(220, 586);
            this.zabado_namelabel.Name = "zabado_namelabel";
            this.zabado_namelabel.Size = new System.Drawing.Size(92, 33);
            this.zabado_namelabel.TabIndex = 50;
            this.zabado_namelabel.Text = "Name";
            // 
            // Redbull_namelabel
            // 
            this.Redbull_namelabel.AutoSize = true;
            this.Redbull_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Redbull_namelabel.Location = new System.Drawing.Point(599, 586);
            this.Redbull_namelabel.Name = "Redbull_namelabel";
            this.Redbull_namelabel.Size = new System.Drawing.Size(92, 33);
            this.Redbull_namelabel.TabIndex = 51;
            this.Redbull_namelabel.Text = "Name";
            // 
            // tropicana_namelabel
            // 
            this.tropicana_namelabel.AutoSize = true;
            this.tropicana_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tropicana_namelabel.Location = new System.Drawing.Point(996, 586);
            this.tropicana_namelabel.Name = "tropicana_namelabel";
            this.tropicana_namelabel.Size = new System.Drawing.Size(92, 33);
            this.tropicana_namelabel.TabIndex = 52;
            this.tropicana_namelabel.Text = "Name";
            // 
            // water_pricelabel
            // 
            this.water_pricelabel.AutoSize = true;
            this.water_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.water_pricelabel.Location = new System.Drawing.Point(248, 302);
            this.water_pricelabel.Name = "water_pricelabel";
            this.water_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.water_pricelabel.TabIndex = 53;
            this.water_pricelabel.Text = "Price";
            // 
            // cocacola_pricelabel
            // 
            this.cocacola_pricelabel.AutoSize = true;
            this.cocacola_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cocacola_pricelabel.Location = new System.Drawing.Point(599, 302);
            this.cocacola_pricelabel.Name = "cocacola_pricelabel";
            this.cocacola_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.cocacola_pricelabel.TabIndex = 54;
            this.cocacola_pricelabel.Text = "Price";
            // 
            // pepsi_labelprice
            // 
            this.pepsi_labelprice.AutoSize = true;
            this.pepsi_labelprice.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pepsi_labelprice.Location = new System.Drawing.Point(1007, 302);
            this.pepsi_labelprice.Name = "pepsi_labelprice";
            this.pepsi_labelprice.Size = new System.Drawing.Size(81, 33);
            this.pepsi_labelprice.TabIndex = 55;
            this.pepsi_labelprice.Text = "Price";
            // 
            // zabado_pricelabel
            // 
            this.zabado_pricelabel.AutoSize = true;
            this.zabado_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zabado_pricelabel.Location = new System.Drawing.Point(220, 619);
            this.zabado_pricelabel.Name = "zabado_pricelabel";
            this.zabado_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.zabado_pricelabel.TabIndex = 56;
            this.zabado_pricelabel.Text = "Price";
            // 
            // Redbull_pricelabel
            // 
            this.Redbull_pricelabel.AutoSize = true;
            this.Redbull_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Redbull_pricelabel.Location = new System.Drawing.Point(610, 619);
            this.Redbull_pricelabel.Name = "Redbull_pricelabel";
            this.Redbull_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.Redbull_pricelabel.TabIndex = 57;
            this.Redbull_pricelabel.Text = "Price";
            // 
            // tropicana_pricelabel
            // 
            this.tropicana_pricelabel.AutoSize = true;
            this.tropicana_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tropicana_pricelabel.Location = new System.Drawing.Point(1007, 619);
            this.tropicana_pricelabel.Name = "tropicana_pricelabel";
            this.tropicana_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.tropicana_pricelabel.TabIndex = 58;
            this.tropicana_pricelabel.Text = "Price";
            // 
            // add_water
            // 
            this.add_water.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_water.ForeColor = System.Drawing.Color.Green;
            this.add_water.Location = new System.Drawing.Point(183, 347);
            this.add_water.Name = "add_water";
            this.add_water.Size = new System.Drawing.Size(173, 34);
            this.add_water.TabIndex = 59;
            this.add_water.Text = "Add To Cart";
            this.add_water.UseVisualStyleBackColor = true;
            this.add_water.Click += new System.EventHandler(this.add_water_Click);
            // 
            // add_cocacola
            // 
            this.add_cocacola.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_cocacola.ForeColor = System.Drawing.Color.Green;
            this.add_cocacola.Location = new System.Drawing.Point(557, 347);
            this.add_cocacola.Name = "add_cocacola";
            this.add_cocacola.Size = new System.Drawing.Size(173, 34);
            this.add_cocacola.TabIndex = 60;
            this.add_cocacola.Text = "Add To Cart";
            this.add_cocacola.UseVisualStyleBackColor = true;
            this.add_cocacola.Click += new System.EventHandler(this.add_cocacola_Click);
            // 
            // add_pepsi
            // 
            this.add_pepsi.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_pepsi.ForeColor = System.Drawing.Color.Green;
            this.add_pepsi.Location = new System.Drawing.Point(955, 347);
            this.add_pepsi.Name = "add_pepsi";
            this.add_pepsi.Size = new System.Drawing.Size(173, 34);
            this.add_pepsi.TabIndex = 61;
            this.add_pepsi.Text = "Add To Cart";
            this.add_pepsi.UseVisualStyleBackColor = true;
            this.add_pepsi.Click += new System.EventHandler(this.add_pepsi_Click);
            // 
            // add_zabado
            // 
            this.add_zabado.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_zabado.ForeColor = System.Drawing.Color.Green;
            this.add_zabado.Location = new System.Drawing.Point(183, 655);
            this.add_zabado.Name = "add_zabado";
            this.add_zabado.Size = new System.Drawing.Size(173, 34);
            this.add_zabado.TabIndex = 62;
            this.add_zabado.Text = "Add To Cart";
            this.add_zabado.UseVisualStyleBackColor = true;
            this.add_zabado.Click += new System.EventHandler(this.add_zabado_Click);
            // 
            // add_redbull
            // 
            this.add_redbull.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_redbull.ForeColor = System.Drawing.Color.Green;
            this.add_redbull.Location = new System.Drawing.Point(557, 655);
            this.add_redbull.Name = "add_redbull";
            this.add_redbull.Size = new System.Drawing.Size(173, 34);
            this.add_redbull.TabIndex = 63;
            this.add_redbull.Text = "Add To Cart";
            this.add_redbull.UseVisualStyleBackColor = true;
            this.add_redbull.Click += new System.EventHandler(this.add_redbull_Click);
            // 
            // add_tropicana
            // 
            this.add_tropicana.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_tropicana.ForeColor = System.Drawing.Color.Green;
            this.add_tropicana.Location = new System.Drawing.Point(966, 655);
            this.add_tropicana.Name = "add_tropicana";
            this.add_tropicana.Size = new System.Drawing.Size(173, 34);
            this.add_tropicana.TabIndex = 64;
            this.add_tropicana.Text = "Add To Cart";
            this.add_tropicana.UseVisualStyleBackColor = true;
            this.add_tropicana.Click += new System.EventHandler(this.add_tropicana_Click);
            // 
            // drinksform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(1321, 718);
            this.Controls.Add(this.add_tropicana);
            this.Controls.Add(this.add_redbull);
            this.Controls.Add(this.add_zabado);
            this.Controls.Add(this.add_pepsi);
            this.Controls.Add(this.add_cocacola);
            this.Controls.Add(this.add_water);
            this.Controls.Add(this.tropicana_pricelabel);
            this.Controls.Add(this.Redbull_pricelabel);
            this.Controls.Add(this.zabado_pricelabel);
            this.Controls.Add(this.pepsi_labelprice);
            this.Controls.Add(this.cocacola_pricelabel);
            this.Controls.Add(this.water_pricelabel);
            this.Controls.Add(this.tropicana_namelabel);
            this.Controls.Add(this.Redbull_namelabel);
            this.Controls.Add(this.zabado_namelabel);
            this.Controls.Add(this.pepsi_namelabel);
            this.Controls.Add(this.cocacola_namelabel);
            this.Controls.Add(this.water_namelabel);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.exitlabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nextlabel);
            this.Controls.Add(this.backlabel);
            this.Controls.Add(this.pictureBox1);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "drinksform";
            this.Text = "drinksform";
            this.Load += new System.EventHandler(this.drinksform_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label backlabel;
        private System.Windows.Forms.Label nextlabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label exitlabel;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label water_namelabel;
        private System.Windows.Forms.Label cocacola_namelabel;
        private System.Windows.Forms.Label pepsi_namelabel;
        private System.Windows.Forms.Label zabado_namelabel;
        private System.Windows.Forms.Label Redbull_namelabel;
        private System.Windows.Forms.Label tropicana_namelabel;
        private System.Windows.Forms.Label water_pricelabel;
        private System.Windows.Forms.Label cocacola_pricelabel;
        private System.Windows.Forms.Label pepsi_labelprice;
        private System.Windows.Forms.Label zabado_pricelabel;
        private System.Windows.Forms.Label Redbull_pricelabel;
        private System.Windows.Forms.Label tropicana_pricelabel;
        private System.Windows.Forms.Button add_water;
        private System.Windows.Forms.Button add_cocacola;
        private System.Windows.Forms.Button add_pepsi;
        private System.Windows.Forms.Button add_zabado;
        private System.Windows.Forms.Button add_redbull;
        private System.Windows.Forms.Button add_tropicana;
    }
}