﻿namespace eventdriven_project
{
    partial class invoiceform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(invoiceform));
            this.label1 = new System.Windows.Forms.Label();
            this.exitlabel = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.invoicetxtbox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.checkoutbutton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.backlabel = new System.Windows.Forms.Label();
            this.deliverybutton = new System.Windows.Forms.Button();
            this.deletebtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(598, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 45);
            this.label1.TabIndex = 2;
            this.label1.Text = "Invoice";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // exitlabel
            // 
            this.exitlabel.AutoSize = true;
            this.exitlabel.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitlabel.ForeColor = System.Drawing.Color.White;
            this.exitlabel.Location = new System.Drawing.Point(1300, 9);
            this.exitlabel.Name = "exitlabel";
            this.exitlabel.Size = new System.Drawing.Size(27, 28);
            this.exitlabel.TabIndex = 40;
            this.exitlabel.Text = "x";
            this.exitlabel.Click += new System.EventHandler(this.exitlabel_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(200, 313);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(216, 151);
            this.dataGridView1.TabIndex = 41;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bookman Old Style", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(563, 313);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(188, 82);
            this.label2.TabIndex = 42;
            this.label2.Text = "Total Price\r\n\r\n";
            // 
            // invoicetxtbox
            // 
            this.invoicetxtbox.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invoicetxtbox.Location = new System.Drawing.Point(816, 322);
            this.invoicetxtbox.Name = "invoicetxtbox";
            this.invoicetxtbox.Size = new System.Drawing.Size(348, 34);
            this.invoicetxtbox.TabIndex = 43;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.DarkGreen;
            this.button1.Location = new System.Drawing.Point(816, 468);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 46);
            this.button1.TabIndex = 44;
            this.button1.Text = "Show";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bookman Old Style", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(246, 207);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 41);
            this.label3.TabIndex = 46;
            this.label3.Text = "Receipt";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // checkoutbutton
            // 
            this.checkoutbutton.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkoutbutton.ForeColor = System.Drawing.Color.DarkGreen;
            this.checkoutbutton.Location = new System.Drawing.Point(1034, 468);
            this.checkoutbutton.Name = "checkoutbutton";
            this.checkoutbutton.Size = new System.Drawing.Size(148, 46);
            this.checkoutbutton.TabIndex = 47;
            this.checkoutbutton.Text = "Checkout";
            this.checkoutbutton.UseVisualStyleBackColor = true;
            this.checkoutbutton.Click += new System.EventHandler(this.checkoutbutton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 48;
            this.pictureBox1.TabStop = false;
            // 
            // backlabel
            // 
            this.backlabel.AutoSize = true;
            this.backlabel.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backlabel.ForeColor = System.Drawing.Color.White;
            this.backlabel.Location = new System.Drawing.Point(47, 683);
            this.backlabel.Name = "backlabel";
            this.backlabel.Size = new System.Drawing.Size(171, 26);
            this.backlabel.TabIndex = 49;
            this.backlabel.Text = "<<<Categories";
            this.backlabel.Click += new System.EventHandler(this.backlabel_Click);
            // 
            // deliverybutton
            // 
            this.deliverybutton.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deliverybutton.ForeColor = System.Drawing.Color.DarkGreen;
            this.deliverybutton.Location = new System.Drawing.Point(938, 546);
            this.deliverybutton.Name = "deliverybutton";
            this.deliverybutton.Size = new System.Drawing.Size(130, 46);
            this.deliverybutton.TabIndex = 50;
            this.deliverybutton.Text = "Delivery";
            this.deliverybutton.UseVisualStyleBackColor = true;
            this.deliverybutton.Click += new System.EventHandler(this.deliverybutton_Click);
            // 
            // deletebtn
            // 
            this.deletebtn.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deletebtn.ForeColor = System.Drawing.Color.DarkGreen;
            this.deletebtn.Location = new System.Drawing.Point(179, 560);
            this.deletebtn.Name = "deletebtn";
            this.deletebtn.Size = new System.Drawing.Size(254, 46);
            this.deletebtn.TabIndex = 51;
            this.deletebtn.Text = "Delete this item";
            this.deletebtn.UseVisualStyleBackColor = true;
            this.deletebtn.Click += new System.EventHandler(this.deletebtn_Click);
            // 
            // invoiceform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(1339, 765);
            this.Controls.Add(this.deletebtn);
            this.Controls.Add(this.deliverybutton);
            this.Controls.Add(this.backlabel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.checkoutbutton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.invoicetxtbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.exitlabel);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "invoiceform";
            this.Text = "invoiceform";
            this.Load += new System.EventHandler(this.invoiceform_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label exitlabel;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox invoicetxtbox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button checkoutbutton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label backlabel;
        private System.Windows.Forms.Button deliverybutton;
        private System.Windows.Forms.Button deletebtn;
    }
}