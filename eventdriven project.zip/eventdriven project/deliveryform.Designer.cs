﻿namespace eventdriven_project
{
    partial class deliveryform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(deliveryform));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Fnametxtbox = new System.Windows.Forms.TextBox();
            this.addresstxtbox = new System.Windows.Forms.TextBox();
            this.Lnametxtbox = new System.Windows.Forms.TextBox();
            this.donebutton = new System.Windows.Forms.Button();
            this.exitlabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(297, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(688, 41);
            this.label1.TabIndex = 2;
            this.label1.Text = "Please Enter Your Information Accurately";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bookman Old Style", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(331, 299);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(196, 41);
            this.label2.TabIndex = 3;
            this.label2.Text = "First Name\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bookman Old Style", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(338, 385);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(189, 41);
            this.label3.TabIndex = 4;
            this.label3.Text = "Last Name\r\n";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bookman Old Style", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(338, 468);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(146, 41);
            this.label4.TabIndex = 5;
            this.label4.Text = "Address\r\n";
            // 
            // Fnametxtbox
            // 
            this.Fnametxtbox.Location = new System.Drawing.Point(629, 316);
            this.Fnametxtbox.Name = "Fnametxtbox";
            this.Fnametxtbox.Size = new System.Drawing.Size(240, 22);
            this.Fnametxtbox.TabIndex = 6;
            // 
            // addresstxtbox
            // 
            this.addresstxtbox.Location = new System.Drawing.Point(629, 485);
            this.addresstxtbox.Name = "addresstxtbox";
            this.addresstxtbox.Size = new System.Drawing.Size(240, 22);
            this.addresstxtbox.TabIndex = 7;
            // 
            // Lnametxtbox
            // 
            this.Lnametxtbox.Location = new System.Drawing.Point(629, 402);
            this.Lnametxtbox.Name = "Lnametxtbox";
            this.Lnametxtbox.Size = new System.Drawing.Size(240, 22);
            this.Lnametxtbox.TabIndex = 8;
            // 
            // donebutton
            // 
            this.donebutton.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.donebutton.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.donebutton.ForeColor = System.Drawing.Color.DarkGreen;
            this.donebutton.Location = new System.Drawing.Point(570, 564);
            this.donebutton.Name = "donebutton";
            this.donebutton.Size = new System.Drawing.Size(121, 46);
            this.donebutton.TabIndex = 9;
            this.donebutton.Text = "Done";
            this.donebutton.UseVisualStyleBackColor = false;
            this.donebutton.Click += new System.EventHandler(this.donebutton_Click);
            // 
            // exitlabel
            // 
            this.exitlabel.AutoSize = true;
            this.exitlabel.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitlabel.Location = new System.Drawing.Point(1300, 9);
            this.exitlabel.Name = "exitlabel";
            this.exitlabel.Size = new System.Drawing.Size(27, 28);
            this.exitlabel.TabIndex = 40;
            this.exitlabel.Text = "x";
            this.exitlabel.Click += new System.EventHandler(this.exitlabel_Click);
            // 
            // deliveryform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(1339, 765);
            this.Controls.Add(this.exitlabel);
            this.Controls.Add(this.donebutton);
            this.Controls.Add(this.Lnametxtbox);
            this.Controls.Add(this.addresstxtbox);
            this.Controls.Add(this.Fnametxtbox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "deliveryform";
            this.Text = "deliveryform";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Fnametxtbox;
        private System.Windows.Forms.TextBox addresstxtbox;
        private System.Windows.Forms.TextBox Lnametxtbox;
        private System.Windows.Forms.Button donebutton;
        private System.Windows.Forms.Label exitlabel;
    }
}