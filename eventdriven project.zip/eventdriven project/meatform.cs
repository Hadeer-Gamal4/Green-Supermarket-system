﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eventdriven_project
{
    public partial class meatform : Form
    {
        public meatform()
        {
            InitializeComponent();
        }

        private void backlabel_Click(object sender, EventArgs e)  //returnung to category
        {
            Categories_form c = new Categories_form();
            c.Show();
            this.Hide();
        }
        //connection to database

        SqlConnection con = new SqlConnection("Data Source=DESKTOP-2QL2JJ3\\SQLEXPRESS01;Initial Catalog=supermarketdatabase;Integrated Security=True");

        //info of redmeat from meattable in supermarketdatabase 
        private void meatform_Load(object sender, EventArgs e)
        {
            string sql = ("SELECT * FROM  [meattable] WHERE parcode='r5ty'");
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            using (SqlDataReader dr = cmd.ExecuteReader())
            {
                if (dr.Read())
                {
                    redmeat_namelabel.Text = dr["name"].ToString();
                    redmeat_pricelabel.Text = dr["price"].ToString();
                }

             //info of turkey from meattable in supermarketdatabase
            }
            string sql1 = ("SELECT * FROM  [meattable] WHERE parcode='ty66'");
            SqlCommand cmd1 = new SqlCommand(sql1, con);
            using (SqlDataReader dm = cmd1.ExecuteReader())
            {
                if (dm.Read())
                {
                    turkey_namelabel.Text = dm["name"].ToString();
                    turkey_pricelabel.Text = dm["price"].ToString();
                }
            }

            //info of chicken from meattable in supermarketdatabase

            string sql2 = ("SELECT * FROM  [meattable] WHERE parcode='yh99'");
            SqlCommand cmd2 = new SqlCommand(sql2, con);
            using (SqlDataReader dm = cmd2.ExecuteReader())
            {
                if (dm.Read())
                {
                    chicken_namelabel.Text = dm["name"].ToString();
                    chicken_pricelabel.Text = dm["price"].ToString();
                }
            }

            //info of burger

            string sql3 = ("SELECT * FROM  [meattable] WHERE parcode='987yh'");
            SqlCommand cmd3 = new SqlCommand(sql3, con);
            using (SqlDataReader dm = cmd3.ExecuteReader())
            {
                if (dm.Read())
                {
                    burger_namelabel.Text = dm["name"].ToString();
                    burger_pricelabel.Text = dm["price"].ToString();
                }
            }

            //info of salmon

            string sql4 = ("SELECT * FROM  [meattable] WHERE parcode='7ytg'");
            SqlCommand cmd4 = new SqlCommand(sql4, con);
            using (SqlDataReader dm = cmd4.ExecuteReader())
            {
                if (dm.Read())
                {
                    salmon_namelabel.Text = dm["name"].ToString();
                    salmon_pricelabel.Text = dm["price"].ToString();
                }
            }

            //info of fish

            string sql5 = ("SELECT * FROM  [meattable] WHERE parcode='gytr56'");
            SqlCommand cmd5 = new SqlCommand(sql5, con);
            using (SqlDataReader dm = cmd5.ExecuteReader())
            {
                if (dm.Read())
                {
                    fish_namelabel.Text = dm["name"].ToString();
                    fish_pricelabel.Text = dm["price"].ToString();
                }
            }


        }

        private void exitlabel_Click(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)   
        {
        }

        private void exitlabel_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label3_Click_1(object sender, EventArgs e)   //turning to invoice
        {
            invoiceform v=new invoiceform();
            v.Show();
            this.Hide();
        }

        private void addredmeat_Click(object sender, EventArgs e)      //adding redmeat to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", redmeat_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void addturkey_Click(object sender, EventArgs e)    //adding turkey to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price",turkey_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void addchicken_Click(object sender, EventArgs e) //adding chicken to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", chicken_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void addburger_Click(object sender, EventArgs e)   //adding burger to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", burger_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void addsalmon_Click(object sender, EventArgs e)   //add salmon to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", salmon_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void addfish_Click(object sender, EventArgs e)   //add fish to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price",fish_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }
    }
}
