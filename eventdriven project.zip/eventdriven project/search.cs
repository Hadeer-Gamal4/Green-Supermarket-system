﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eventdriven_project
{
    public partial class search : Form
    {
        public search()
        {
            InitializeComponent();
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            try
            {

                //searching product in milktable
                if (searchtxtbox.Text.Trim() == string.Empty)
                {
                    MessageBox.Show("cannot be Empty");
                }
                else
                {
                    SqlConnection con = new SqlConnection("Data Source=DESKTOP-2QL2JJ3\\SQLEXPRESS01;Initial Catalog=supermarketdatabase;Integrated Security=True");
                    SqlCommand cmd = new SqlCommand("SELECT * FROM [milktable] WHERE name LIKE '%" + searchtxtbox.Text + "%'", con);
                    con.Open();
                    cmd.Connection = con;
                    using (SqlDataReader dm = cmd.ExecuteReader())
                    {
                        if (dm.Read())
                        {

                            //if the item is found so application sends the user to the form where searched product is

                            MessageBox.Show("This Item Is Found");
                            Milkdetailsform m1 = new Milkdetailsform();
                            m1.Show();
                            this.Hide();

                        }
                    }


                    //searching product in meattable

                    SqlCommand cmd1 = new SqlCommand("SELECT * FROM [meattable] WHERE name LIKE '%" + searchtxtbox.Text + "%'", con);
                    cmd1.Connection = con;
                    using (SqlDataReader dm1 = cmd1.ExecuteReader())
                    {
                        if (dm1.Read())
                        {

                            //if the item is found so application sends the user to the form where searched product is

                            MessageBox.Show("This Item Is Found");
                            meatform m1 = new meatform();
                            m1.Show();
                            this.Hide();


                        }
                    }

                    //searching product in snackstable

                    SqlCommand cmd2 = new SqlCommand("SELECT * FROM [snackstable] WHERE name LIKE '%" + searchtxtbox.Text + "%'", con);
                    cmd2.Connection = con;
                    using (SqlDataReader dm2 = cmd2.ExecuteReader())
                    {
                        if (dm2.Read())
                        {

                            //if the item is found so application sends the user to the form where searched product is

                            MessageBox.Show("This Item Is Found");
                            snacksform snacksform = new snacksform();
                            snacksform.Show();
                            this.Hide();

                        }

                    }

                    //searching product in drinkstable

                    SqlCommand cmd3 = new SqlCommand("SELECT * FROM [drinkstable] WHERE name LIKE '%" + searchtxtbox.Text + "%'", con);
                    cmd3.Connection = con;
                    using (SqlDataReader dm3 = cmd3.ExecuteReader())
                    {
                        if (dm3.Read())
                        {

                            //if the item is found so application sends the user to the form where searched product is

                            MessageBox.Show("This Item Is Found");
                            drinksform d = new drinksform();
                            d.Show();
                            this.Hide();

                        }

                    }

                    //searching product in cheesetable

                    SqlCommand cmd4 = new SqlCommand("SELECT * FROM [cheesetable] WHERE name LIKE '%" + searchtxtbox.Text + "%'", con);
                    cmd4.Connection = con;
                    using (SqlDataReader dm4 = cmd4.ExecuteReader())
                    {
                        if (dm4.Read())
                        {

                            //if the item is found so application sends the user to the form where searched product is

                            MessageBox.Show("This Item Is Found");
                            cheeseform c1 = new cheeseform();
                            c1.Show();
                            this.Hide();

                        }

                    }
                    con.Close();
                }
            }
            catch
            {
                label1.Text = "Sorry,Product Not Found";
            }

        }
    }
}
