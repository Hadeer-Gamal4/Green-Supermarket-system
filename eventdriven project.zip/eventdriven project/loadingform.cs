﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eventdriven_project
{
    public partial class loadingform : Form
    {
        public loadingform()
        {
            InitializeComponent();
        }
        int startpoint = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            startpoint += 1;
            myprogress.Value = startpoint;
            if (myprogress.Value == 100)
            {
                myprogress.Value = 0;
                timer1.Stop();
            }
        }


        private void loadingform_Load(object sender, EventArgs e)    //timer starts when opening application
        {
            timer1.Start();
        }
        private void label2_Click(object sender, EventArgs e)   //x symbol for closing
        {
            this.Close();
        }

        private void myprogress_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            loginform l2 = new loginform();
            this.Hide();
            l2.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
