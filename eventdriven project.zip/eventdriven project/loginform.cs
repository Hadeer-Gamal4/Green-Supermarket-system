﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace eventdriven_project
{
    public partial class loginform : Form
    {
        public loginform()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {
        }
        private void label1_Click_1(object sender, EventArgs e)
        { 
        }
        private void label4_Click(object sender, EventArgs e)
        {
        }
        private void label6_Click(object sender, EventArgs e)   //x symbol label in the top of page
        {
            this.Close();    //closing function in order to exit
        }

        private void button1_Click(object sender, EventArgs e)    //button of sign up in the left of page to connect it to registeration form in order to make an account
        {
            signupform s1 = new signupform();
            this.Hide();
            s1.Show();
        }

        private void loginform_Load(object sender, EventArgs e)
        {
        }

        private void loginbutton_Click(object sender, EventArgs e)
        {
            if (loginusertxtbox.Text.Trim() == string.Empty ||passlogintxtbox.Text.Trim() == String.Empty)  //in order to check if any of the textboxes is empty and displaying a message for user
            {
                MessageBox.Show("Sorry,All fields must contain an answer");
            }
            else
            {
                try
                {
                    SqlConnection conn = new SqlConnection("Data Source=DESKTOP-2QL2JJ3\\SQLEXPRESS01;Initial Catalog=supermarketdatabase;Integrated Security=True");  //connection string for connecting the database
                    SqlCommand cmd = new SqlCommand("select * from signinguptable where username=@username and password=@password", conn);   //connecting to certain table in our database
                    cmd.Parameters.AddWithValue("@username", loginusertxtbox.Text);    
                    cmd.Parameters.AddWithValue("@password", passlogintxtbox.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        MessageBox.Show("Login successfully");
                        searchingproducts s = new searchingproducts();   //connecting login form to searching form
                        s.Show();
                        this.Hide();
                        
                    }

                    else
                    {
                        MessageBox.Show("Username or password is wrong");
                    }

                    
                }

                catch
                {
                    MessageBox.Show("sorry,something went wrong");
                }
            }
        }

        private void label5_Click(object sender, EventArgs e)
        { 
        }
    }
}
