﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eventdriven_project
{
    public partial class Categories_form : Form
    {
        public Categories_form()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void milkproducts_Click(object sender, EventArgs e)  //selecting milk so sending to milk products details
        {
            Milkdetailsform m=new Milkdetailsform();
            m.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)  //cheese category selected
        {
            cheeseform cheeseform1 = new cheeseform();
            cheeseform1.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)  //exiting form
        {
            this.Close();
        }

        private void meatproducts_Click(object sender, EventArgs e)  //meat catogery selected
        {
            meatform meatform1 = new meatform();
            meatform1.Show();
            this.Hide();
        }

        private void snacksproducts_Click(object sender, EventArgs e)    //snacks category selected
        {
            snacksform snacksform1 = new snacksform();
            snacksform1.Show();
            this.Hide();
        }

        private void pictureBox5_Click(object sender, EventArgs e)      //drinks selected
        {
            drinksform drinksform1 = new drinksform();
            drinksform1.Show();
            this.Hide();
        }
    }
}
