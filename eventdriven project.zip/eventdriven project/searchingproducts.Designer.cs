﻿namespace eventdriven_project
{
    partial class searchingproducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(searchingproducts));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.searchtxtbox = new System.Windows.Forms.TextBox();
            this.exitlabel = new System.Windows.Forms.Label();
            this.searchbutton = new System.Windows.Forms.Button();
            this.go_categories = new System.Windows.Forms.Label();
            this.backlbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.notfoundlabel = new System.Windows.Forms.Label();
            this.tableAdapterManager1 = new eventdriven_project.supermarketdatabaseDataSetTableAdapters.TableAdapterManager();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 49;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(501, 209);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(364, 41);
            this.label1.TabIndex = 50;
            this.label1.Text = "Search For A Product\r\n";
            // 
            // searchtxtbox
            // 
            this.searchtxtbox.Location = new System.Drawing.Point(450, 307);
            this.searchtxtbox.Name = "searchtxtbox";
            this.searchtxtbox.Size = new System.Drawing.Size(520, 22);
            this.searchtxtbox.TabIndex = 51;
            // 
            // exitlabel
            // 
            this.exitlabel.AutoSize = true;
            this.exitlabel.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitlabel.ForeColor = System.Drawing.Color.White;
            this.exitlabel.Location = new System.Drawing.Point(1300, 9);
            this.exitlabel.Name = "exitlabel";
            this.exitlabel.Size = new System.Drawing.Size(27, 28);
            this.exitlabel.TabIndex = 52;
            this.exitlabel.Text = "x";
            this.exitlabel.Click += new System.EventHandler(this.exitlabel_Click);
            // 
            // searchbutton
            // 
            this.searchbutton.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchbutton.ForeColor = System.Drawing.Color.Green;
            this.searchbutton.Location = new System.Drawing.Point(602, 375);
            this.searchbutton.Name = "searchbutton";
            this.searchbutton.Size = new System.Drawing.Size(173, 34);
            this.searchbutton.TabIndex = 53;
            this.searchbutton.Text = "Search\r\n";
            this.searchbutton.UseVisualStyleBackColor = true;
            this.searchbutton.Click += new System.EventHandler(this.searchbutton_Click);
            // 
            // go_categories
            // 
            this.go_categories.AutoSize = true;
            this.go_categories.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.go_categories.ForeColor = System.Drawing.Color.DarkGreen;
            this.go_categories.Location = new System.Drawing.Point(877, 556);
            this.go_categories.Name = "go_categories";
            this.go_categories.Size = new System.Drawing.Size(281, 33);
            this.go_categories.TabIndex = 54;
            this.go_categories.Text = "Go To Categories>>";
            this.go_categories.Click += new System.EventHandler(this.go_categories_Click);
            // 
            // backlbl
            // 
            this.backlbl.AutoSize = true;
            this.backlbl.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backlbl.ForeColor = System.Drawing.Color.DarkGreen;
            this.backlbl.Location = new System.Drawing.Point(234, 566);
            this.backlbl.Name = "backlbl";
            this.backlbl.Size = new System.Drawing.Size(118, 33);
            this.backlbl.TabIndex = 55;
            this.backlbl.Text = "<<Back\r\n";
            this.backlbl.Click += new System.EventHandler(this.backlbl_Click);
            // 
            // label2
            // 
            //this.label2.AutoSize = true;
            //this.label2.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            //this.label2.ForeColor = System.Drawing.Color.Red;
            //this.label2.Location = new System.Drawing.Point(638, 456);
            //this.label2.Name = "label2";
            //this.label2.Size = new System.Drawing.Size(0, 23);
            //this.label2.TabIndex = 56;
            // 
            // notfoundlabel
            // 
            //this.notfoundlabel.AutoSize = true;
            //this.notfoundlabel.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            //this.notfoundlabel.ForeColor = System.Drawing.Color.Red;
            //this.notfoundlabel.Location = new System.Drawing.Point(656, 440);
            //this.notfoundlabel.Name = "notfoundlabel";
            //this.notfoundlabel.Size = new System.Drawing.Size(0, 26);
            //this.notfoundlabel.TabIndex = 58;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.milksTableAdapter = null;
            this.tableAdapterManager1.milktableTableAdapter = null;
            this.tableAdapterManager1.registertableTableAdapter = null;
            this.tableAdapterManager1.signuptableTableAdapter = null;
            this.tableAdapterManager1.UpdateOrder = eventdriven_project.supermarketdatabaseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // label3
            // 
            //this.label3.AutoSize = true;
            //this.label3.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            //this.label3.ForeColor = System.Drawing.Color.Red;
            //this.label3.Location = new System.Drawing.Point(662, 440);
            //this.label3.Name = "label3";
            //this.label3.Size = new System.Drawing.Size(0, 26);
            //this.label3.TabIndex = 59;
            //this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(664, 430);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 26);
            this.label4.TabIndex = 60;
            // 
            // searchingproducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(1339, 765);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.notfoundlabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.backlbl);
            this.Controls.Add(this.go_categories);
            this.Controls.Add(this.searchbutton);
            this.Controls.Add(this.exitlabel);
            this.Controls.Add(this.searchtxtbox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "searchingproducts";
            this.Text = "searchingproducts";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox searchtxtbox;
        private System.Windows.Forms.Label exitlabel;
        private System.Windows.Forms.Button searchbutton;
        private System.Windows.Forms.Label go_categories;
        private System.Windows.Forms.Label backlbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label notfoundlabel;
        private supermarketdatabaseDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}