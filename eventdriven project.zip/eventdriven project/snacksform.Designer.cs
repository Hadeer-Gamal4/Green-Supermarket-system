﻿namespace eventdriven_project
{
    partial class snacksform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(snacksform));
            this.backlabel = new System.Windows.Forms.Label();
            this.nextlabel = new System.Windows.Forms.Label();
            this.exitlabel = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.cheetos_namelabel = new System.Windows.Forms.Label();
            this.forno_namelabel = new System.Windows.Forms.Label();
            this.bebeto_namelabel = new System.Windows.Forms.Label();
            this.milka_namelabel = new System.Windows.Forms.Label();
            this.cocoa_namelabel = new System.Windows.Forms.Label();
            this.haribo_namelabel = new System.Windows.Forms.Label();
            this.cheetos_pricelabel = new System.Windows.Forms.Label();
            this.forno_pricelabel = new System.Windows.Forms.Label();
            this.bebeto_pricelabel = new System.Windows.Forms.Label();
            this.milka_pricelabel = new System.Windows.Forms.Label();
            this.cocea_pricelabel = new System.Windows.Forms.Label();
            this.haribo_pricelabel = new System.Windows.Forms.Label();
            this.add_cheetos = new System.Windows.Forms.Button();
            this.add_forno = new System.Windows.Forms.Button();
            this.add_bebeto = new System.Windows.Forms.Button();
            this.add_milka = new System.Windows.Forms.Button();
            this.add_cocoa = new System.Windows.Forms.Button();
            this.add_haribo = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // backlabel
            // 
            this.backlabel.AutoSize = true;
            this.backlabel.Font = new System.Drawing.Font("Bookman Old Style", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backlabel.Location = new System.Drawing.Point(263, 28);
            this.backlabel.Name = "backlabel";
            this.backlabel.Size = new System.Drawing.Size(49, 20);
            this.backlabel.TabIndex = 35;
            this.backlabel.Text = "<<<<";
            this.backlabel.Click += new System.EventHandler(this.backlabel_Click);
            // 
            // nextlabel
            // 
            this.nextlabel.AutoSize = true;
            this.nextlabel.Font = new System.Drawing.Font("Bookman Old Style", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nextlabel.Location = new System.Drawing.Point(757, 28);
            this.nextlabel.Name = "nextlabel";
            this.nextlabel.Size = new System.Drawing.Size(49, 20);
            this.nextlabel.TabIndex = 36;
            this.nextlabel.Text = ">>>>";
            this.nextlabel.Click += new System.EventHandler(this.nextlabel_Click);
            // 
            // exitlabel
            // 
            this.exitlabel.AutoSize = true;
            this.exitlabel.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitlabel.Location = new System.Drawing.Point(1100, 9);
            this.exitlabel.Name = "exitlabel";
            this.exitlabel.Size = new System.Drawing.Size(27, 28);
            this.exitlabel.TabIndex = 37;
            this.exitlabel.Text = "x";
            this.exitlabel.Click += new System.EventHandler(this.exitlabel_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Bookman Old Style", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(370, 9);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(349, 90);
            this.label17.TabIndex = 38;
            this.label17.Text = "Snacks Products\r\n\r\n";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 39;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(107, 91);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(229, 207);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 40;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(446, 78);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(229, 207);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 41;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(789, 78);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(229, 207);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 42;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(107, 416);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(229, 207);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 43;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(446, 416);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(229, 207);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 44;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(789, 416);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(229, 207);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 45;
            this.pictureBox7.TabStop = false;
            // 
            // cheetos_namelabel
            // 
            this.cheetos_namelabel.AutoSize = true;
            this.cheetos_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheetos_namelabel.Location = new System.Drawing.Point(176, 301);
            this.cheetos_namelabel.Name = "cheetos_namelabel";
            this.cheetos_namelabel.Size = new System.Drawing.Size(92, 33);
            this.cheetos_namelabel.TabIndex = 46;
            this.cheetos_namelabel.Text = "Name";
            // 
            // forno_namelabel
            // 
            this.forno_namelabel.AutoSize = true;
            this.forno_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.forno_namelabel.Location = new System.Drawing.Point(514, 288);
            this.forno_namelabel.Name = "forno_namelabel";
            this.forno_namelabel.Size = new System.Drawing.Size(92, 33);
            this.forno_namelabel.TabIndex = 47;
            this.forno_namelabel.Text = "Name";
            // 
            // bebeto_namelabel
            // 
            this.bebeto_namelabel.AutoSize = true;
            this.bebeto_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bebeto_namelabel.Location = new System.Drawing.Point(858, 288);
            this.bebeto_namelabel.Name = "bebeto_namelabel";
            this.bebeto_namelabel.Size = new System.Drawing.Size(92, 33);
            this.bebeto_namelabel.TabIndex = 48;
            this.bebeto_namelabel.Text = "Name";
            // 
            // milka_namelabel
            // 
            this.milka_namelabel.AutoSize = true;
            this.milka_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.milka_namelabel.Location = new System.Drawing.Point(176, 626);
            this.milka_namelabel.Name = "milka_namelabel";
            this.milka_namelabel.Size = new System.Drawing.Size(92, 33);
            this.milka_namelabel.TabIndex = 49;
            this.milka_namelabel.Text = "Name";
            // 
            // cocoa_namelabel
            // 
            this.cocoa_namelabel.AutoSize = true;
            this.cocoa_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cocoa_namelabel.Location = new System.Drawing.Point(514, 626);
            this.cocoa_namelabel.Name = "cocoa_namelabel";
            this.cocoa_namelabel.Size = new System.Drawing.Size(92, 33);
            this.cocoa_namelabel.TabIndex = 50;
            this.cocoa_namelabel.Text = "Name";
            // 
            // haribo_namelabel
            // 
            this.haribo_namelabel.AutoSize = true;
            this.haribo_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.haribo_namelabel.Location = new System.Drawing.Point(858, 626);
            this.haribo_namelabel.Name = "haribo_namelabel";
            this.haribo_namelabel.Size = new System.Drawing.Size(92, 33);
            this.haribo_namelabel.TabIndex = 51;
            this.haribo_namelabel.Text = "Name";
            // 
            // cheetos_pricelabel
            // 
            this.cheetos_pricelabel.AutoSize = true;
            this.cheetos_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheetos_pricelabel.Location = new System.Drawing.Point(176, 334);
            this.cheetos_pricelabel.Name = "cheetos_pricelabel";
            this.cheetos_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.cheetos_pricelabel.TabIndex = 52;
            this.cheetos_pricelabel.Text = "Price";
            // 
            // forno_pricelabel
            // 
            this.forno_pricelabel.AutoSize = true;
            this.forno_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.forno_pricelabel.Location = new System.Drawing.Point(514, 321);
            this.forno_pricelabel.Name = "forno_pricelabel";
            this.forno_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.forno_pricelabel.TabIndex = 53;
            this.forno_pricelabel.Text = "Price";
            // 
            // bebeto_pricelabel
            // 
            this.bebeto_pricelabel.AutoSize = true;
            this.bebeto_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bebeto_pricelabel.Location = new System.Drawing.Point(858, 321);
            this.bebeto_pricelabel.Name = "bebeto_pricelabel";
            this.bebeto_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.bebeto_pricelabel.TabIndex = 54;
            this.bebeto_pricelabel.Text = "Price";
            // 
            // milka_pricelabel
            // 
            this.milka_pricelabel.AutoSize = true;
            this.milka_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.milka_pricelabel.Location = new System.Drawing.Point(176, 659);
            this.milka_pricelabel.Name = "milka_pricelabel";
            this.milka_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.milka_pricelabel.TabIndex = 55;
            this.milka_pricelabel.Text = "Price";
            // 
            // cocea_pricelabel
            // 
            this.cocea_pricelabel.AutoSize = true;
            this.cocea_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cocea_pricelabel.Location = new System.Drawing.Point(514, 659);
            this.cocea_pricelabel.Name = "cocea_pricelabel";
            this.cocea_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.cocea_pricelabel.TabIndex = 56;
            this.cocea_pricelabel.Text = "Price";
            // 
            // haribo_pricelabel
            // 
            this.haribo_pricelabel.AutoSize = true;
            this.haribo_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.haribo_pricelabel.Location = new System.Drawing.Point(869, 659);
            this.haribo_pricelabel.Name = "haribo_pricelabel";
            this.haribo_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.haribo_pricelabel.TabIndex = 57;
            this.haribo_pricelabel.Text = "Price";
            // 
            // add_cheetos
            // 
            this.add_cheetos.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_cheetos.ForeColor = System.Drawing.Color.Green;
            this.add_cheetos.Location = new System.Drawing.Point(139, 370);
            this.add_cheetos.Name = "add_cheetos";
            this.add_cheetos.Size = new System.Drawing.Size(173, 34);
            this.add_cheetos.TabIndex = 58;
            this.add_cheetos.Text = "Add To Cart";
            this.add_cheetos.UseVisualStyleBackColor = true;
            this.add_cheetos.Click += new System.EventHandler(this.add_cheetos_Click);
            // 
            // add_forno
            // 
            this.add_forno.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_forno.ForeColor = System.Drawing.Color.Green;
            this.add_forno.Location = new System.Drawing.Point(478, 370);
            this.add_forno.Name = "add_forno";
            this.add_forno.Size = new System.Drawing.Size(173, 34);
            this.add_forno.TabIndex = 59;
            this.add_forno.Text = "Add To Cart";
            this.add_forno.UseVisualStyleBackColor = true;
            this.add_forno.Click += new System.EventHandler(this.add_forno_Click);
            // 
            // add_bebeto
            // 
            this.add_bebeto.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_bebeto.ForeColor = System.Drawing.Color.Green;
            this.add_bebeto.Location = new System.Drawing.Point(825, 370);
            this.add_bebeto.Name = "add_bebeto";
            this.add_bebeto.Size = new System.Drawing.Size(173, 34);
            this.add_bebeto.TabIndex = 60;
            this.add_bebeto.Text = "Add To Cart";
            this.add_bebeto.UseVisualStyleBackColor = true;
            this.add_bebeto.Click += new System.EventHandler(this.add_bebeto_Click);
            // 
            // add_milka
            // 
            this.add_milka.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_milka.ForeColor = System.Drawing.Color.Green;
            this.add_milka.Location = new System.Drawing.Point(129, 695);
            this.add_milka.Name = "add_milka";
            this.add_milka.Size = new System.Drawing.Size(173, 34);
            this.add_milka.TabIndex = 61;
            this.add_milka.Text = "Add To Cart";
            this.add_milka.UseVisualStyleBackColor = true;
            this.add_milka.Click += new System.EventHandler(this.add_milka_Click);
            // 
            // add_cocoa
            // 
            this.add_cocoa.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_cocoa.ForeColor = System.Drawing.Color.Green;
            this.add_cocoa.Location = new System.Drawing.Point(478, 695);
            this.add_cocoa.Name = "add_cocoa";
            this.add_cocoa.Size = new System.Drawing.Size(173, 34);
            this.add_cocoa.TabIndex = 62;
            this.add_cocoa.Text = "Add To Cart";
            this.add_cocoa.UseVisualStyleBackColor = true;
            this.add_cocoa.Click += new System.EventHandler(this.add_cocoa_Click);
            // 
            // add_haribo
            // 
            this.add_haribo.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_haribo.ForeColor = System.Drawing.Color.Green;
            this.add_haribo.Location = new System.Drawing.Point(825, 695);
            this.add_haribo.Name = "add_haribo";
            this.add_haribo.Size = new System.Drawing.Size(173, 34);
            this.add_haribo.TabIndex = 63;
            this.add_haribo.Text = "Add To Cart";
            this.add_haribo.UseVisualStyleBackColor = true;
            this.add_haribo.Click += new System.EventHandler(this.add_haribo_Click);
            // 
            // snacksform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(1139, 765);
            this.Controls.Add(this.add_haribo);
            this.Controls.Add(this.add_cocoa);
            this.Controls.Add(this.add_milka);
            this.Controls.Add(this.add_bebeto);
            this.Controls.Add(this.add_forno);
            this.Controls.Add(this.add_cheetos);
            this.Controls.Add(this.haribo_pricelabel);
            this.Controls.Add(this.cocea_pricelabel);
            this.Controls.Add(this.milka_pricelabel);
            this.Controls.Add(this.bebeto_pricelabel);
            this.Controls.Add(this.forno_pricelabel);
            this.Controls.Add(this.cheetos_pricelabel);
            this.Controls.Add(this.haribo_namelabel);
            this.Controls.Add(this.cocoa_namelabel);
            this.Controls.Add(this.milka_namelabel);
            this.Controls.Add(this.bebeto_namelabel);
            this.Controls.Add(this.forno_namelabel);
            this.Controls.Add(this.cheetos_namelabel);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.exitlabel);
            this.Controls.Add(this.nextlabel);
            this.Controls.Add(this.backlabel);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "snacksform";
            this.Text = "snacksform";
            this.Load += new System.EventHandler(this.snacksform_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label backlabel;
        private System.Windows.Forms.Label nextlabel;
        private System.Windows.Forms.Label exitlabel;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label cheetos_namelabel;
        private System.Windows.Forms.Label forno_namelabel;
        private System.Windows.Forms.Label bebeto_namelabel;
        private System.Windows.Forms.Label milka_namelabel;
        private System.Windows.Forms.Label cocoa_namelabel;
        private System.Windows.Forms.Label haribo_namelabel;
        private System.Windows.Forms.Label cheetos_pricelabel;
        private System.Windows.Forms.Label forno_pricelabel;
        private System.Windows.Forms.Label bebeto_pricelabel;
        private System.Windows.Forms.Label milka_pricelabel;
        private System.Windows.Forms.Label cocea_pricelabel;
        private System.Windows.Forms.Label haribo_pricelabel;
        private System.Windows.Forms.Button add_cheetos;
        private System.Windows.Forms.Button add_forno;
        private System.Windows.Forms.Button add_bebeto;
        private System.Windows.Forms.Button add_milka;
        private System.Windows.Forms.Button add_cocoa;
        private System.Windows.Forms.Button add_haribo;
    }
}