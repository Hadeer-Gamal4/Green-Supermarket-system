﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eventdriven_project
{
    internal class deliveryclass   
    {
        //attributes of the class
        public string fname { get; set; }     //using setters and getters
        public string lname { get; set; }
        public string address { get; set; }

        public DataTable select()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-2QL2JJ3\\SQLEXPRESS01;Initial Catalog=supermarketdatabase;Integrated Security=True");
            DataTable dt = new DataTable();
            try
            {
                string sql = "SELECT * FROM deliverytable";
                SqlCommand cmd = new SqlCommand(sql, con);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                con.Open();
                adapter.Fill(dt);
            }
            catch
            {

            }
            finally
            {
                con.Close();
            }
            return dt;
        }
        public bool Insert(deliveryclass c)    //we take object from class deliveryclass and pass it to the function as arguments
        {
            bool successs = false;
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-2QL2JJ3\\SQLEXPRESS01;Initial Catalog=supermarketdatabase;Integrated Security=True");
            try
            {
                string sql = "INSERT INTO deliverytable VALUES(@firstname,@lastname,@address)";  //quering by inserting 
                SqlCommand cmd = new SqlCommand(sql, con);

                //inserting the objects to its corrosponding feild in the table

                cmd.Parameters.AddWithValue("@firstname", c.fname);  
                cmd.Parameters.AddWithValue("@lastname", c.lname);
                cmd.Parameters.AddWithValue("@address", c.address);
                con.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                {
                    successs = true;
                }
                else
                {
                    successs = false;

                }
            }
            catch
            {

            }
            finally
            {
                con.Close();
            }
            return successs;
        }

    }

}
        
