﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eventdriven_project
{
    public partial class drinksform : Form
    {
        public drinksform()
        {
            InitializeComponent();
        }

        //connection string

        SqlConnection con = new SqlConnection("Data Source=DESKTOP-2QL2JJ3\\SQLEXPRESS01;Initial Catalog=supermarketdatabase;Integrated Security=True");
        private void drinksform_Load(object sender, EventArgs e)
        {
            //info of water

            string sql = ("SELECT * FROM  [drinkstable] WHERE parcode='4erf3'");
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            using (SqlDataReader dr = cmd.ExecuteReader())
            {
                if (dr.Read())
                {
                    water_namelabel.Text = dr["name"].ToString();
                    water_pricelabel.Text = dr["price"].ToString();
                }

            }

            //info of cocacola

            string sql1 = ("SELECT * FROM  [drinkstable] WHERE parcode='3efde'");
            SqlCommand cmd1 = new SqlCommand(sql1, con);
            using (SqlDataReader dr = cmd1.ExecuteReader())
            {
                if (dr.Read())
                {
                    cocacola_namelabel.Text = dr["name"].ToString();
                    cocacola_pricelabel.Text = dr["price"].ToString();
                }

            }

            //info pepsi

            string sql2 = ("SELECT * FROM  [drinkstable] WHERE parcode='8uyhg'");
            SqlCommand cmd2 = new SqlCommand(sql2, con);
            using (SqlDataReader dr = cmd2.ExecuteReader())
            {
                if (dr.Read())
                {
                    pepsi_namelabel.Text = dr["name"].ToString();
                    pepsi_labelprice.Text = dr["price"].ToString();
                }

            }

            //info of zabado

            string sql3 = ("SELECT * FROM  [drinkstable] WHERE parcode='7yhgt'");
            SqlCommand cmd3 = new SqlCommand(sql3, con);
            using (SqlDataReader dr = cmd3.ExecuteReader())
            {
                if (dr.Read())
                {
                    zabado_namelabel.Text = dr["name"].ToString();
                    zabado_pricelabel.Text = dr["price"].ToString();
                }

            }

            //info of redbull

            string sql4 = ("SELECT * FROM  [drinkstable] WHERE parcode='juythg'");
            SqlCommand cmd4 = new SqlCommand(sql4, con);
            using (SqlDataReader dr = cmd4.ExecuteReader())
            {
                if (dr.Read())
                {
                    Redbull_namelabel.Text = dr["name"].ToString();
                    Redbull_pricelabel.Text = dr["price"].ToString();
                }

            }

            //info of tropicana

            string sql5 = ("SELECT * FROM  [drinkstable] WHERE parcode='9iuyh'");
            SqlCommand cmd5 = new SqlCommand(sql5, con);
            using (SqlDataReader dr = cmd5.ExecuteReader())
            {
                if (dr.Read())
                {
                    tropicana_namelabel.Text = dr["name"].ToString();
                    tropicana_pricelabel.Text = dr["price"].ToString();
                }

            }


        }
            private void add_water_Click(object sender, EventArgs e)   //adding water to receipt and shopping cart
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", water_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void backlabel_Click(object sender, EventArgs e)
        {
            Categories_form f1=new Categories_form();
            f1.Show();
            this.Hide();
        }

        private void nextlabel_Click(object sender, EventArgs e)
        {
            invoiceform f1 = new invoiceform();
            f1.Show();
            this.Hide();
        }

        private void exitlabel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void add_cocacola_Click(object sender, EventArgs e)    //adding cocacola to cart
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", cocacola_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void add_pepsi_Click(object sender, EventArgs e)     //adding pepsi to cart
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", pepsi_labelprice.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void add_zabado_Click(object sender, EventArgs e)   //adding zabado to cart
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", zabado_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void add_redbull_Click(object sender, EventArgs e)   //adding redbull to cart
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", Redbull_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void add_tropicana_Click(object sender, EventArgs e)  //adding tropicaan to cart
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", tropicana_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }
    }
}
