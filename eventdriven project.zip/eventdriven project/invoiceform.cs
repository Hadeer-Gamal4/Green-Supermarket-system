﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace eventdriven_project
{
    public partial class invoiceform : Form
    {
        public invoiceform()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        //connection string

        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-2QL2JJ3\\SQLEXPRESS01;Initial Catalog=supermarketdatabase;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)   //summing prices of products user selected and showing it in textbox
        {
            int sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                sum += int.Parse(dataGridView1.Rows[i].Cells[0].Value.ToString());
            }
            invoicetxtbox.Text = sum.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        { 
        }

        private void exitlabel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void backlabel_Click(object sender, EventArgs e)
        {
            Categories_form f1 = new Categories_form();
            f1.Show();
            this.Hide();
        }



        private void invoiceform_Load(object sender, EventArgs e)    
        {
            //connecting between the datagrid view by the totalpricetable in the database 
            //in order to make dagrid view able to display the table

                SqlCommand cmd = new SqlCommand("Select price From [totalpricetable]", conn);  //queuring by using select
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
        }

        private void checkoutbutton_Click(object sender, EventArgs e)  //sending user to delivery section
        {
            
            dataGridView1.Columns.Clear();
            conn.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM [dbo].[totalpricetable]", conn);  //queuring by using insert
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Receipt saved successfully");
        }

        private void deliverybutton_Click(object sender, EventArgs e)
        {
            deliveryform f1 = new deliveryform();
            f1.Show();
            this.Hide();
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            int rowindex = dataGridView1.CurrentCell.RowIndex;
            dataGridView1.Rows.RemoveAt(rowindex);
        }
    }
    }
