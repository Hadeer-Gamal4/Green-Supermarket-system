﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eventdriven_project
{
    public partial class snacksform : Form
    {
        public snacksform()
        {
            InitializeComponent();
        }

        private void backlabel_Click(object sender, EventArgs e)
        {
            Categories_form categories_Form1=new Categories_form();
            categories_Form1.Show();
            this.Hide();
        }

        private void nextlabel_Click(object sender, EventArgs e)
        {
            invoiceform v1 = new invoiceform();
            v1.Show();
            this.Hide();
        }

        private void exitlabel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //string connection 
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-2QL2JJ3\\SQLEXPRESS01;Initial Catalog=supermarketdatabase;Integrated Security=True");
        private void snacksform_Load(object sender, EventArgs e)
        {
            //cheetos 

            string sql = ("SELECT * FROM  [snackstable] WHERE parcode='5trgf'");
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            using (SqlDataReader dr = cmd.ExecuteReader())
            {
                if (dr.Read())
                {
                    cheetos_namelabel.Text = dr["name"].ToString();
                    cheetos_pricelabel.Text = dr["price"].ToString();
                }
            }
             
            //forno

            string sql1 = ("SELECT * FROM  [snackstable] WHERE parcode='76yfs'");
            SqlCommand cmd1 = new SqlCommand(sql1, con);
            using (SqlDataReader dr = cmd1.ExecuteReader())
            {
                if (dr.Read())
                {
                    forno_namelabel.Text = dr["name"].ToString();
                    forno_pricelabel.Text= dr["price"].ToString();
                }
            }

              //bebeto

            string sql2 = ("SELECT * FROM  [snackstable] WHERE parcode='hyju6'");
            SqlCommand cmd2= new SqlCommand(sql2, con);
            using (SqlDataReader dr = cmd2.ExecuteReader())
            {
                if (dr.Read())
                {
                    bebeto_namelabel.Text= dr["name"].ToString();
                    bebeto_pricelabel.Text = dr["price"].ToString();
                }
            }
             
            //milka

            string sql3 = ("SELECT * FROM  [snackstable] WHERE parcode='kiu7y'");
            SqlCommand cmd3 = new SqlCommand(sql3, con);
            using (SqlDataReader dr = cmd3.ExecuteReader())
            {
                if (dr.Read())
                {
                    milka_namelabel.Text= dr["name"].ToString();
                    milka_pricelabel.Text = dr["price"].ToString();
                }
            }

            //cocoalover

            string sql4 = ("SELECT * FROM  [snackstable] WHERE parcode='76ywbs'");
            SqlCommand cmd4 = new SqlCommand(sql4, con);
            using (SqlDataReader dr = cmd4.ExecuteReader())
            {
                if (dr.Read())
                {
                    cocoa_namelabel.Text = dr["name"].ToString();
                    cocea_pricelabel.Text = dr["price"].ToString();
                }
            }

            //haribo

            string sql5 = ("SELECT * FROM  [snackstable] WHERE parcode='lpou76'");
            SqlCommand cmd5 = new SqlCommand(sql5, con);
            using (SqlDataReader dr = cmd5.ExecuteReader())
            {
                if (dr.Read())
                {
                    haribo_namelabel.Text = dr["name"].ToString();
                    haribo_pricelabel.Text = dr["price"].ToString();
                }
            }



        }

        private void add_cheetos_Click(object sender, EventArgs e)    //adding cheetos 
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", cheetos_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void add_forno_Click(object sender, EventArgs e)  //adding forno
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", forno_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void add_bebeto_Click(object sender, EventArgs e)  //adding bebeto
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", bebeto_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void add_milka_Click(object sender, EventArgs e)  //adding milka
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", milka_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void add_cocoa_Click(object sender, EventArgs e)   //adding cocea
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", cocea_pricelabel);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void add_haribo_Click(object sender, EventArgs e)  //adding haribo
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", haribo_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }
    }
}
