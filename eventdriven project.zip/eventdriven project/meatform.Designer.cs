﻿namespace eventdriven_project
{
    partial class meatform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(meatform));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.backlabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.exitlabel = new System.Windows.Forms.Label();
            this.redmeat_namelabel = new System.Windows.Forms.Label();
            this.redmeat_pricelabel = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.turkey_namelabel = new System.Windows.Forms.Label();
            this.chicken_namelabel = new System.Windows.Forms.Label();
            this.turkey_pricelabel = new System.Windows.Forms.Label();
            this.chicken_pricelabel = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.burger_namelabel = new System.Windows.Forms.Label();
            this.salmon_namelabel = new System.Windows.Forms.Label();
            this.fish_namelabel = new System.Windows.Forms.Label();
            this.burger_pricelabel = new System.Windows.Forms.Label();
            this.salmon_pricelabel = new System.Windows.Forms.Label();
            this.fish_pricelabel = new System.Windows.Forms.Label();
            this.addredmeat = new System.Windows.Forms.Button();
            this.addturkey = new System.Windows.Forms.Button();
            this.addchicken = new System.Windows.Forms.Button();
            this.addburger = new System.Windows.Forms.Button();
            this.addsalmon = new System.Windows.Forms.Button();
            this.addfish = new System.Windows.Forms.Button();
            this.tableAdapterManager1 = new eventdriven_project.supermarketdatabaseDataSetTableAdapters.TableAdapterManager();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // backlabel
            // 
            this.backlabel.AutoSize = true;
            this.backlabel.Font = new System.Drawing.Font("Bookman Old Style", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backlabel.ForeColor = System.Drawing.Color.White;
            this.backlabel.Location = new System.Drawing.Point(357, 30);
            this.backlabel.Name = "backlabel";
            this.backlabel.Size = new System.Drawing.Size(49, 20);
            this.backlabel.TabIndex = 1;
            this.backlabel.Text = "<<<<";
            this.backlabel.Click += new System.EventHandler(this.backlabel_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bookman Old Style", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(517, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(250, 41);
            this.label2.TabIndex = 2;
            this.label2.Text = "Meat Products";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bookman Old Style", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(922, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = ">>>>";
            this.label3.Click += new System.EventHandler(this.label3_Click_1);
            // 
            // exitlabel
            // 
            this.exitlabel.AutoSize = true;
            this.exitlabel.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitlabel.ForeColor = System.Drawing.Color.White;
            this.exitlabel.Location = new System.Drawing.Point(1282, 9);
            this.exitlabel.Name = "exitlabel";
            this.exitlabel.Size = new System.Drawing.Size(27, 28);
            this.exitlabel.TabIndex = 4;
            this.exitlabel.Text = "x";
            this.exitlabel.Click += new System.EventHandler(this.exitlabel_Click_1);
            // 
            // redmeat_namelabel
            // 
            this.redmeat_namelabel.AutoSize = true;
            this.redmeat_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.redmeat_namelabel.ForeColor = System.Drawing.Color.White;
            this.redmeat_namelabel.Location = new System.Drawing.Point(189, 256);
            this.redmeat_namelabel.Name = "redmeat_namelabel";
            this.redmeat_namelabel.Size = new System.Drawing.Size(92, 33);
            this.redmeat_namelabel.TabIndex = 12;
            this.redmeat_namelabel.Text = "Name";
            // 
            // redmeat_pricelabel
            // 
            this.redmeat_pricelabel.AutoSize = true;
            this.redmeat_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.redmeat_pricelabel.ForeColor = System.Drawing.Color.White;
            this.redmeat_pricelabel.Location = new System.Drawing.Point(189, 289);
            this.redmeat_pricelabel.Name = "redmeat_pricelabel";
            this.redmeat_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.redmeat_pricelabel.TabIndex = 13;
            this.redmeat_pricelabel.Text = "Price";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(146, 118);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(206, 135);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(542, 118);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(206, 135);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(926, 118);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(206, 135);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 16;
            this.pictureBox4.TabStop = false;
            // 
            // turkey_namelabel
            // 
            this.turkey_namelabel.AutoSize = true;
            this.turkey_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.turkey_namelabel.ForeColor = System.Drawing.Color.White;
            this.turkey_namelabel.Location = new System.Drawing.Point(593, 256);
            this.turkey_namelabel.Name = "turkey_namelabel";
            this.turkey_namelabel.Size = new System.Drawing.Size(92, 33);
            this.turkey_namelabel.TabIndex = 17;
            this.turkey_namelabel.Text = "Name";
            // 
            // chicken_namelabel
            // 
            this.chicken_namelabel.AutoSize = true;
            this.chicken_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chicken_namelabel.ForeColor = System.Drawing.Color.White;
            this.chicken_namelabel.Location = new System.Drawing.Point(987, 256);
            this.chicken_namelabel.Name = "chicken_namelabel";
            this.chicken_namelabel.Size = new System.Drawing.Size(92, 33);
            this.chicken_namelabel.TabIndex = 18;
            this.chicken_namelabel.Text = "Name";
            // 
            // turkey_pricelabel
            // 
            this.turkey_pricelabel.AutoSize = true;
            this.turkey_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.turkey_pricelabel.ForeColor = System.Drawing.Color.White;
            this.turkey_pricelabel.Location = new System.Drawing.Point(593, 289);
            this.turkey_pricelabel.Name = "turkey_pricelabel";
            this.turkey_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.turkey_pricelabel.TabIndex = 19;
            this.turkey_pricelabel.Text = "Price";
            // 
            // chicken_pricelabel
            // 
            this.chicken_pricelabel.AutoSize = true;
            this.chicken_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chicken_pricelabel.ForeColor = System.Drawing.Color.White;
            this.chicken_pricelabel.Location = new System.Drawing.Point(998, 289);
            this.chicken_pricelabel.Name = "chicken_pricelabel";
            this.chicken_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.chicken_pricelabel.TabIndex = 20;
            this.chicken_pricelabel.Text = "Price";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(146, 398);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(206, 135);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 21;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(524, 398);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(206, 135);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 22;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(926, 398);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(206, 135);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 23;
            this.pictureBox7.TabStop = false;
            // 
            // burger_namelabel
            // 
            this.burger_namelabel.AutoSize = true;
            this.burger_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.burger_namelabel.ForeColor = System.Drawing.Color.White;
            this.burger_namelabel.Location = new System.Drawing.Point(200, 536);
            this.burger_namelabel.Name = "burger_namelabel";
            this.burger_namelabel.Size = new System.Drawing.Size(92, 33);
            this.burger_namelabel.TabIndex = 24;
            this.burger_namelabel.Text = "Name";
            // 
            // salmon_namelabel
            // 
            this.salmon_namelabel.AutoSize = true;
            this.salmon_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salmon_namelabel.ForeColor = System.Drawing.Color.White;
            this.salmon_namelabel.Location = new System.Drawing.Point(582, 536);
            this.salmon_namelabel.Name = "salmon_namelabel";
            this.salmon_namelabel.Size = new System.Drawing.Size(92, 33);
            this.salmon_namelabel.TabIndex = 25;
            this.salmon_namelabel.Text = "Name";
            // 
            // fish_namelabel
            // 
            this.fish_namelabel.AutoSize = true;
            this.fish_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fish_namelabel.ForeColor = System.Drawing.Color.White;
            this.fish_namelabel.Location = new System.Drawing.Point(987, 536);
            this.fish_namelabel.Name = "fish_namelabel";
            this.fish_namelabel.Size = new System.Drawing.Size(92, 33);
            this.fish_namelabel.TabIndex = 26;
            this.fish_namelabel.Text = "Name";
            // 
            // burger_pricelabel
            // 
            this.burger_pricelabel.AutoSize = true;
            this.burger_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.burger_pricelabel.ForeColor = System.Drawing.Color.White;
            this.burger_pricelabel.Location = new System.Drawing.Point(200, 572);
            this.burger_pricelabel.Name = "burger_pricelabel";
            this.burger_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.burger_pricelabel.TabIndex = 27;
            this.burger_pricelabel.Text = "Price";
            // 
            // salmon_pricelabel
            // 
            this.salmon_pricelabel.AutoSize = true;
            this.salmon_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salmon_pricelabel.ForeColor = System.Drawing.Color.White;
            this.salmon_pricelabel.Location = new System.Drawing.Point(593, 572);
            this.salmon_pricelabel.Name = "salmon_pricelabel";
            this.salmon_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.salmon_pricelabel.TabIndex = 28;
            this.salmon_pricelabel.Text = "Price";
            // 
            // fish_pricelabel
            // 
            this.fish_pricelabel.AutoSize = true;
            this.fish_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fish_pricelabel.ForeColor = System.Drawing.Color.White;
            this.fish_pricelabel.Location = new System.Drawing.Point(998, 572);
            this.fish_pricelabel.Name = "fish_pricelabel";
            this.fish_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.fish_pricelabel.TabIndex = 29;
            this.fish_pricelabel.Text = "Price";
            // 
            // addredmeat
            // 
            this.addredmeat.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addredmeat.ForeColor = System.Drawing.Color.DarkGreen;
            this.addredmeat.Location = new System.Drawing.Point(157, 325);
            this.addredmeat.Name = "addredmeat";
            this.addredmeat.Size = new System.Drawing.Size(157, 35);
            this.addredmeat.TabIndex = 30;
            this.addredmeat.Text = "Add To Cart";
            this.addredmeat.UseVisualStyleBackColor = true;
            this.addredmeat.Click += new System.EventHandler(this.addredmeat_Click);
            // 
            // addturkey
            // 
            this.addturkey.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addturkey.ForeColor = System.Drawing.Color.DarkGreen;
            this.addturkey.Location = new System.Drawing.Point(573, 325);
            this.addturkey.Name = "addturkey";
            this.addturkey.Size = new System.Drawing.Size(157, 35);
            this.addturkey.TabIndex = 31;
            this.addturkey.Text = "Add To Cart";
            this.addturkey.UseVisualStyleBackColor = true;
            this.addturkey.Click += new System.EventHandler(this.addturkey_Click);
            // 
            // addchicken
            // 
            this.addchicken.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addchicken.ForeColor = System.Drawing.Color.DarkGreen;
            this.addchicken.Location = new System.Drawing.Point(954, 325);
            this.addchicken.Name = "addchicken";
            this.addchicken.Size = new System.Drawing.Size(157, 35);
            this.addchicken.TabIndex = 32;
            this.addchicken.Text = "Add To Cart";
            this.addchicken.UseVisualStyleBackColor = true;
            this.addchicken.Click += new System.EventHandler(this.addchicken_Click);
            // 
            // addburger
            // 
            this.addburger.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addburger.ForeColor = System.Drawing.Color.DarkGreen;
            this.addburger.Location = new System.Drawing.Point(157, 608);
            this.addburger.Name = "addburger";
            this.addburger.Size = new System.Drawing.Size(157, 35);
            this.addburger.TabIndex = 33;
            this.addburger.Text = "Add To Cart";
            this.addburger.UseVisualStyleBackColor = true;
            this.addburger.Click += new System.EventHandler(this.addburger_Click);
            // 
            // addsalmon
            // 
            this.addsalmon.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addsalmon.ForeColor = System.Drawing.Color.DarkGreen;
            this.addsalmon.Location = new System.Drawing.Point(559, 608);
            this.addsalmon.Name = "addsalmon";
            this.addsalmon.Size = new System.Drawing.Size(157, 35);
            this.addsalmon.TabIndex = 34;
            this.addsalmon.Text = "Add To Cart";
            this.addsalmon.UseVisualStyleBackColor = true;
            this.addsalmon.Click += new System.EventHandler(this.addsalmon_Click);
            // 
            // addfish
            // 
            this.addfish.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addfish.ForeColor = System.Drawing.Color.DarkGreen;
            this.addfish.Location = new System.Drawing.Point(963, 608);
            this.addfish.Name = "addfish";
            this.addfish.Size = new System.Drawing.Size(157, 35);
            this.addfish.TabIndex = 35;
            this.addfish.Text = "Add To Cart";
            this.addfish.UseVisualStyleBackColor = true;
            this.addfish.Click += new System.EventHandler(this.addfish_Click);
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.milksTableAdapter = null;
            this.tableAdapterManager1.milktableTableAdapter = null;
            this.tableAdapterManager1.registertableTableAdapter = null;
            this.tableAdapterManager1.signuptableTableAdapter = null;
            this.tableAdapterManager1.UpdateOrder = eventdriven_project.supermarketdatabaseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // meatform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(1321, 718);
            this.Controls.Add(this.addfish);
            this.Controls.Add(this.addsalmon);
            this.Controls.Add(this.addburger);
            this.Controls.Add(this.addchicken);
            this.Controls.Add(this.addturkey);
            this.Controls.Add(this.addredmeat);
            this.Controls.Add(this.fish_pricelabel);
            this.Controls.Add(this.salmon_pricelabel);
            this.Controls.Add(this.burger_pricelabel);
            this.Controls.Add(this.fish_namelabel);
            this.Controls.Add(this.salmon_namelabel);
            this.Controls.Add(this.burger_namelabel);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.chicken_pricelabel);
            this.Controls.Add(this.turkey_pricelabel);
            this.Controls.Add(this.chicken_namelabel);
            this.Controls.Add(this.turkey_namelabel);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.redmeat_pricelabel);
            this.Controls.Add(this.redmeat_namelabel);
            this.Controls.Add(this.exitlabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.backlabel);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "meatform";
            this.Text = "meatform";
            this.Load += new System.EventHandler(this.meatform_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label backlabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label exitlabel;
        private System.Windows.Forms.Label redmeat_namelabel;
        private System.Windows.Forms.Label redmeat_pricelabel;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label turkey_namelabel;
        private System.Windows.Forms.Label chicken_namelabel;
        private System.Windows.Forms.Label turkey_pricelabel;
        private System.Windows.Forms.Label chicken_pricelabel;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label burger_namelabel;
        private System.Windows.Forms.Label salmon_namelabel;
        private System.Windows.Forms.Label fish_namelabel;
        private System.Windows.Forms.Label burger_pricelabel;
        private System.Windows.Forms.Label salmon_pricelabel;
        private System.Windows.Forms.Label fish_pricelabel;
        private System.Windows.Forms.Button addredmeat;
        private System.Windows.Forms.Button addturkey;
        private System.Windows.Forms.Button addchicken;
        private System.Windows.Forms.Button addburger;
        private System.Windows.Forms.Button addsalmon;
        private System.Windows.Forms.Button addfish;
        private supermarketdatabaseDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
    }
}