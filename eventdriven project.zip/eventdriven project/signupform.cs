﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Net.Http.Headers;
using System.Data.SqlClient;
using System.Data.Common;

namespace eventdriven_project
{
    public partial class signupform : Form
    {
        public signupform()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)    //x label for exit
        {
            this.Close();
        }

        private void registerbutton_Click(object sender, EventArgs e)
        {
            //checking if textboxes is empty or not
            try
            {
                if (registerphonetxtbox.Text.Trim() == string.Empty || registernametxtbox.Text.Trim() == String.Empty || registerpasstxtbox.Text.Trim() == String.Empty)
                {
                    MessageBox.Show("Sorry,All fields should contain an answer");
                    return;
                }

                //input validation for phone number and password

                //phone number its validation is to contain only numbers

                //password must contain upper,lower letters and numbers

                var hasnumber1 = new Regex(@"[0-9]+");        //validating range of numbers
                var hasupperchar1 = new Regex(@"[A-Z]+");
                var haslowerchar1 = new Regex(@"[a-z]+");
                var hasnumber = new Regex(@"[0-9]+");
                var hasupperchar = new Regex(@"[A-Z]+");     //validation for upper case
                var haslowerchar = new Regex(@"[a-z]+");     //validation for lower case

                if (!hasnumber1.IsMatch(registerphonetxtbox.Text) || hasupperchar1.IsMatch(registerphonetxtbox.Text) || haslowerchar1.IsMatch(registerphonetxtbox.Text))            //phone number validation
                {
                    MessageBox.Show("Sorry,Phone number should contain only numbers");
                }

                if (!hasnumber.IsMatch(registerpasstxtbox.Text) || !hasupperchar.IsMatch(registerpasstxtbox.Text) || !haslowerchar.IsMatch(registerpasstxtbox.Text))   //password validation
                {
                    MessageBox.Show("Sorry,Your password should include upper,lower letters and at least one number");
                }

                else
                {
                    SqlConnection con = new SqlConnection("Data Source=DESKTOP-2QL2JJ3\\SQLEXPRESS01;Initial Catalog=supermarketdatabase;Integrated Security=True");
                    con.Open();     //opening connection
                    SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[signinguptable] VALUES(@phonenumber,@username,@password)", con);

                    //Adding values in our textboxes in the database table in it's corrosping field

                    cmd.Parameters.AddWithValue("@phonenumber", registerphonetxtbox.Text);
                    cmd.Parameters.AddWithValue("@username", registernametxtbox.Text);
                    cmd.Parameters.AddWithValue("@password", registerpasstxtbox.Text);
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Register successfully");
                    con.Close();  //closing connection
                }



                loginform f1 = new loginform();       //returning back to login form in order to login and then passing you to categories
                f1.Show();
                this.Hide();
            }
             catch                 //as if anything went wrong like not being able to convert a text entered through textbox from one form datatybe to another
            {
                MessageBox.Show("Sorry,You entered something wrong");
            }

        }

    }
}

    



            
   
