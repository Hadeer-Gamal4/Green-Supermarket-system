﻿namespace eventdriven_project
{
    partial class Milkdetailsform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Milkdetailsform));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.juhayna_namelabel = new System.Windows.Forms.Label();
            this.juhayna_pricelabel = new System.Windows.Forms.Label();
            this.nido_namelabel = new System.Windows.Forms.Label();
            this.nido_pricelabel = new System.Windows.Forms.Label();
            this.dailyfarmer_namelabel = new System.Windows.Forms.Label();
            this.dailyfarmer_pricelabel = new System.Windows.Forms.Label();
            this.dinafarms_pricelabel = new System.Windows.Forms.Label();
            this.dinafarms_namelabel = new System.Windows.Forms.Label();
            this.almarainamelabel = new System.Windows.Forms.Label();
            this.marai_pricelabel = new System.Windows.Forms.Label();
            this.lactel_namelabel = new System.Windows.Forms.Label();
            this.lactel_pricelabel = new System.Windows.Forms.Label();
            this.addjuhayna = new System.Windows.Forms.Button();
            this.addlactel = new System.Windows.Forms.Button();
            this.adddailyfarmer = new System.Windows.Forms.Button();
            this.adddinafarms = new System.Windows.Forms.Button();
            this.addalmarai = new System.Windows.Forms.Button();
            this.addnido = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.backlabel = new System.Windows.Forms.Label();
            this.nextlabel = new System.Windows.Forms.Label();
            this.exitlabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(176, 94);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(202, 202);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(583, 94);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(202, 202);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(966, 94);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(202, 202);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(176, 430);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(202, 202);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(583, 430);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(202, 202);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(966, 430);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(202, 202);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 6;
            this.pictureBox7.TabStop = false;
            // 
            // juhayna_namelabel
            // 
            this.juhayna_namelabel.AutoSize = true;
            this.juhayna_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.juhayna_namelabel.Location = new System.Drawing.Point(214, 305);
            this.juhayna_namelabel.Name = "juhayna_namelabel";
            this.juhayna_namelabel.Size = new System.Drawing.Size(0, 33);
            this.juhayna_namelabel.TabIndex = 8;
            // 
            // juhayna_pricelabel
            // 
            this.juhayna_pricelabel.AutoSize = true;
            this.juhayna_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.juhayna_pricelabel.Location = new System.Drawing.Point(214, 338);
            this.juhayna_pricelabel.Name = "juhayna_pricelabel";
            this.juhayna_pricelabel.Size = new System.Drawing.Size(0, 33);
            this.juhayna_pricelabel.TabIndex = 9;
            // 
            // nido_namelabel
            // 
            this.nido_namelabel.AutoSize = true;
            this.nido_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nido_namelabel.Location = new System.Drawing.Point(633, 305);
            this.nido_namelabel.Name = "nido_namelabel";
            this.nido_namelabel.Size = new System.Drawing.Size(92, 33);
            this.nido_namelabel.TabIndex = 10;
            this.nido_namelabel.Text = "Name";
            // 
            // nido_pricelabel
            // 
            this.nido_pricelabel.AutoSize = true;
            this.nido_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nido_pricelabel.Location = new System.Drawing.Point(633, 338);
            this.nido_pricelabel.Name = "nido_pricelabel";
            this.nido_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.nido_pricelabel.TabIndex = 11;
            this.nido_pricelabel.Text = "Price";
            // 
            // dailyfarmer_namelabel
            // 
            this.dailyfarmer_namelabel.AutoSize = true;
            this.dailyfarmer_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dailyfarmer_namelabel.Location = new System.Drawing.Point(1013, 305);
            this.dailyfarmer_namelabel.Name = "dailyfarmer_namelabel";
            this.dailyfarmer_namelabel.Size = new System.Drawing.Size(92, 33);
            this.dailyfarmer_namelabel.TabIndex = 12;
            this.dailyfarmer_namelabel.Text = "Name";
            // 
            // dailyfarmer_pricelabel
            // 
            this.dailyfarmer_pricelabel.AutoSize = true;
            this.dailyfarmer_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dailyfarmer_pricelabel.Location = new System.Drawing.Point(1013, 338);
            this.dailyfarmer_pricelabel.Name = "dailyfarmer_pricelabel";
            this.dailyfarmer_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.dailyfarmer_pricelabel.TabIndex = 13;
            this.dailyfarmer_pricelabel.Text = "Price";
            // 
            // dinafarms_pricelabel
            // 
            this.dinafarms_pricelabel.AutoSize = true;
            this.dinafarms_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dinafarms_pricelabel.Location = new System.Drawing.Point(1013, 672);
            this.dinafarms_pricelabel.Name = "dinafarms_pricelabel";
            this.dinafarms_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.dinafarms_pricelabel.TabIndex = 14;
            this.dinafarms_pricelabel.Text = "Price";
            // 
            // dinafarms_namelabel
            // 
            this.dinafarms_namelabel.AutoSize = true;
            this.dinafarms_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dinafarms_namelabel.Location = new System.Drawing.Point(1013, 645);
            this.dinafarms_namelabel.Name = "dinafarms_namelabel";
            this.dinafarms_namelabel.Size = new System.Drawing.Size(92, 33);
            this.dinafarms_namelabel.TabIndex = 15;
            this.dinafarms_namelabel.Text = "Name";
            // 
            // almarainamelabel
            // 
            this.almarainamelabel.AutoSize = true;
            this.almarainamelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.almarainamelabel.Location = new System.Drawing.Point(218, 635);
            this.almarainamelabel.Name = "almarainamelabel";
            this.almarainamelabel.Size = new System.Drawing.Size(92, 33);
            this.almarainamelabel.TabIndex = 16;
            this.almarainamelabel.Text = "Name";
            // 
            // marai_pricelabel
            // 
            this.marai_pricelabel.AutoSize = true;
            this.marai_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.marai_pricelabel.Location = new System.Drawing.Point(229, 672);
            this.marai_pricelabel.Name = "marai_pricelabel";
            this.marai_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.marai_pricelabel.TabIndex = 17;
            this.marai_pricelabel.Text = "Price";
            // 
            // lactel_namelabel
            // 
            this.lactel_namelabel.AutoSize = true;
            this.lactel_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lactel_namelabel.Location = new System.Drawing.Point(633, 645);
            this.lactel_namelabel.Name = "lactel_namelabel";
            this.lactel_namelabel.Size = new System.Drawing.Size(92, 33);
            this.lactel_namelabel.TabIndex = 18;
            this.lactel_namelabel.Text = "Name";
            // 
            // lactel_pricelabel
            // 
            this.lactel_pricelabel.AutoSize = true;
            this.lactel_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lactel_pricelabel.Location = new System.Drawing.Point(633, 672);
            this.lactel_pricelabel.Name = "lactel_pricelabel";
            this.lactel_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.lactel_pricelabel.TabIndex = 19;
            this.lactel_pricelabel.Text = "Price";
            // 
            // addjuhayna
            // 
            this.addjuhayna.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addjuhayna.ForeColor = System.Drawing.Color.Green;
            this.addjuhayna.Location = new System.Drawing.Point(193, 381);
            this.addjuhayna.Name = "addjuhayna";
            this.addjuhayna.Size = new System.Drawing.Size(173, 34);
            this.addjuhayna.TabIndex = 24;
            this.addjuhayna.Text = "Add To Cart";
            this.addjuhayna.UseVisualStyleBackColor = true;
            this.addjuhayna.Click += new System.EventHandler(this.addjuhayna_Click);
            // 
            // addlactel
            // 
            this.addlactel.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addlactel.ForeColor = System.Drawing.Color.Green;
            this.addlactel.Location = new System.Drawing.Point(594, 714);
            this.addlactel.Name = "addlactel";
            this.addlactel.Size = new System.Drawing.Size(173, 34);
            this.addlactel.TabIndex = 25;
            this.addlactel.Text = "Add To Cart";
            this.addlactel.UseVisualStyleBackColor = true;
            this.addlactel.Click += new System.EventHandler(this.addlactel_Click);
            // 
            // adddailyfarmer
            // 
            this.adddailyfarmer.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adddailyfarmer.ForeColor = System.Drawing.Color.Green;
            this.adddailyfarmer.Location = new System.Drawing.Point(982, 381);
            this.adddailyfarmer.Name = "adddailyfarmer";
            this.adddailyfarmer.Size = new System.Drawing.Size(173, 34);
            this.adddailyfarmer.TabIndex = 26;
            this.adddailyfarmer.Text = "Add To Cart";
            this.adddailyfarmer.UseVisualStyleBackColor = true;
            this.adddailyfarmer.Click += new System.EventHandler(this.adddailyfarmer_Click);
            // 
            // adddinafarms
            // 
            this.adddinafarms.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adddinafarms.ForeColor = System.Drawing.Color.Green;
            this.adddinafarms.Location = new System.Drawing.Point(982, 714);
            this.adddinafarms.Name = "adddinafarms";
            this.adddinafarms.Size = new System.Drawing.Size(173, 34);
            this.adddinafarms.TabIndex = 27;
            this.adddinafarms.Text = "Add To Cart";
            this.adddinafarms.UseVisualStyleBackColor = true;
            this.adddinafarms.Click += new System.EventHandler(this.adddinafarms_Click);
            // 
            // addalmarai
            // 
            this.addalmarai.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addalmarai.ForeColor = System.Drawing.Color.Green;
            this.addalmarai.Location = new System.Drawing.Point(193, 714);
            this.addalmarai.Name = "addalmarai";
            this.addalmarai.Size = new System.Drawing.Size(173, 34);
            this.addalmarai.TabIndex = 28;
            this.addalmarai.Text = "Add To Cart";
            this.addalmarai.UseVisualStyleBackColor = true;
            this.addalmarai.Click += new System.EventHandler(this.addalmarai_Click);
            // 
            // addnido
            // 
            this.addnido.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addnido.ForeColor = System.Drawing.Color.Green;
            this.addnido.Location = new System.Drawing.Point(594, 381);
            this.addnido.Name = "addnido";
            this.addnido.Size = new System.Drawing.Size(173, 34);
            this.addnido.TabIndex = 29;
            this.addnido.Text = "Add To Cart";
            this.addnido.UseVisualStyleBackColor = true;
            this.addnido.Click += new System.EventHandler(this.addnido_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Bookman Old Style", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(526, 1);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(293, 45);
            this.label17.TabIndex = 32;
            this.label17.Text = "Milk Products";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(0, 1);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(110, 50);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 33;
            this.pictureBox9.TabStop = false;
            // 
            // backlabel
            // 
            this.backlabel.AutoSize = true;
            this.backlabel.Font = new System.Drawing.Font("Bookman Old Style", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backlabel.Location = new System.Drawing.Point(299, 16);
            this.backlabel.Name = "backlabel";
            this.backlabel.Size = new System.Drawing.Size(49, 20);
            this.backlabel.TabIndex = 34;
            this.backlabel.Text = "<<<<";
            this.backlabel.Click += new System.EventHandler(this.backlabel_Click);
            // 
            // nextlabel
            // 
            this.nextlabel.AutoSize = true;
            this.nextlabel.Font = new System.Drawing.Font("Bookman Old Style", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nextlabel.Location = new System.Drawing.Point(1059, 14);
            this.nextlabel.Name = "nextlabel";
            this.nextlabel.Size = new System.Drawing.Size(49, 20);
            this.nextlabel.TabIndex = 35;
            this.nextlabel.Text = ">>>>";
            this.nextlabel.Click += new System.EventHandler(this.nextlabel_Click);
            // 
            // exitlabel
            // 
            this.exitlabel.AutoSize = true;
            this.exitlabel.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitlabel.Location = new System.Drawing.Point(1300, 10);
            this.exitlabel.Name = "exitlabel";
            this.exitlabel.Size = new System.Drawing.Size(27, 28);
            this.exitlabel.TabIndex = 36;
            this.exitlabel.Text = "x";
            this.exitlabel.Click += new System.EventHandler(this.exitlabel_Click);
            // 
            // Milkdetailsform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(1339, 765);
            this.Controls.Add(this.exitlabel);
            this.Controls.Add(this.nextlabel);
            this.Controls.Add(this.backlabel);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.addnido);
            this.Controls.Add(this.addalmarai);
            this.Controls.Add(this.adddinafarms);
            this.Controls.Add(this.adddailyfarmer);
            this.Controls.Add(this.addlactel);
            this.Controls.Add(this.addjuhayna);
            this.Controls.Add(this.lactel_pricelabel);
            this.Controls.Add(this.lactel_namelabel);
            this.Controls.Add(this.marai_pricelabel);
            this.Controls.Add(this.almarainamelabel);
            this.Controls.Add(this.dinafarms_namelabel);
            this.Controls.Add(this.dinafarms_pricelabel);
            this.Controls.Add(this.dailyfarmer_pricelabel);
            this.Controls.Add(this.dailyfarmer_namelabel);
            this.Controls.Add(this.nido_pricelabel);
            this.Controls.Add(this.nido_namelabel);
            this.Controls.Add(this.juhayna_pricelabel);
            this.Controls.Add(this.juhayna_namelabel);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Milkdetailsform";
            this.Text = "Milkdetailsform";
            this.Load += new System.EventHandler(this.Milkdetailsform_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label juhayna_namelabel;
        private System.Windows.Forms.Label juhayna_pricelabel;
        private System.Windows.Forms.Label nido_namelabel;
        private System.Windows.Forms.Label nido_pricelabel;
        private System.Windows.Forms.Label dailyfarmer_namelabel;
        private System.Windows.Forms.Label dailyfarmer_pricelabel;
        private System.Windows.Forms.Label dinafarms_pricelabel;
        private System.Windows.Forms.Label dinafarms_namelabel;
        private System.Windows.Forms.Label almarainamelabel;
        private System.Windows.Forms.Label marai_pricelabel;
        private System.Windows.Forms.Label lactel_namelabel;
        private System.Windows.Forms.Label lactel_pricelabel;
        private System.Windows.Forms.Button addjuhayna;
        private System.Windows.Forms.Button addlactel;
        private System.Windows.Forms.Button adddailyfarmer;
        private System.Windows.Forms.Button adddinafarms;
        private System.Windows.Forms.Button addalmarai;
        private System.Windows.Forms.Button addnido;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label backlabel;
        private System.Windows.Forms.Label nextlabel;
        private System.Windows.Forms.Label exitlabel;
    }
}