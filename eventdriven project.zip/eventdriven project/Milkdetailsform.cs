﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eventdriven_project
{
    public partial class Milkdetailsform : Form
    {
        public Milkdetailsform()
        {
            InitializeComponent();
        }

        /*private void label17_Click(object sender, EventArgs e)
        {
        }
        private void pictureBox9_Click(object sender, EventArgs e)
        {
        }
        private void pictureBox4_Click(object sender, EventArgs e)
        {
        }*/

        private void backlabel_Click(object sender, EventArgs e)  //label when user clicks on it sending him to previous page
        {
            Categories_form c1 = new Categories_form();
            c1.Show();
            this.Hide();
        }

        private void nextlabel_Click(object sender, EventArgs e)  //label when user clicks on it sending him to next page
        {
            invoiceform f1 = new invoiceform();
            f1.Show();
            this.Hide();
        }

        private void exitlabel_Click(object sender, EventArgs e)  //x symbol for exit
        {
            this.Close();
        }

        //connection string in order connecting to server that contains our database

        SqlConnection con = new SqlConnection("Data Source=DESKTOP-2QL2JJ3\\SQLEXPRESS01;Initial Catalog=supermarketdatabase;Integrated Security=True");

        //parcode for juhayna milk and displaying its data from datatable

        private void Milkdetailsform_Load(object sender, EventArgs e)
        {
            string sql = ("SELECT * FROM  [milktable] WHERE parcode='1212'");     
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            using (SqlDataReader dr = cmd.ExecuteReader())
            {
                if (dr.Read())
                {
                    juhayna_namelabel.Text = dr["name"].ToString();
                    juhayna_pricelabel.Text = dr["price"].ToString();
                }
            }

            //parcode for nido milk 

            string sql1 = ("SELECT * FROM  [milktable] WHERE parcode='7654'");
            SqlCommand cmd1 = new SqlCommand(sql1, con);
            using (SqlDataReader dr = cmd1.ExecuteReader())
            {
                if (dr.Read())
                {
                    nido_namelabel.Text = dr["name"].ToString();
                    nido_pricelabel.Text = dr["price"].ToString();
                }
            }

            //parcode for lactel milk and its information from database displayed for user

            string sql2 = ("SELECT * FROM  [milktable] WHERE parcode='76y5'");
            SqlCommand cmd2 = new SqlCommand(sql2, con);
            using (SqlDataReader dr = cmd2.ExecuteReader())
            {
                if (dr.Read())
                {
                    lactel_namelabel.Text = dr["name"].ToString();
                    lactel_pricelabel.Text = dr["price"].ToString();
                }
            }

            //parcode for dina farms milk diplaying info from database even after updating

            string sql3 = ("SELECT * FROM  [milktable] WHERE parcode='9uhdb'");
            SqlCommand cmd3 = new SqlCommand(sql3, con);
            using (SqlDataReader dr = cmd3.ExecuteReader())
            {
                if (dr.Read())
                {
                    dinafarms_namelabel.Text = dr["name"].ToString();
                    dinafarms_pricelabel.Text = dr["price"].ToString();
                }
            }

            //parcode for marai milk displaying info

            string sql4 = ("SELECT * FROM  [milktable] WHERE parcode='p8y5'");
            SqlCommand cmd4 = new SqlCommand(sql4, con);
            using (SqlDataReader dr = cmd4.ExecuteReader())
            {
                if (dr.Read())
                {
                    almarainamelabel.Text = dr["name"].ToString();
                    marai_pricelabel.Text = dr["price"].ToString();
                }
            }

            //parcode for dairyfarmers

            string sql5 = ("SELECT * FROM  [milktable] WHERE parcode='oi8y'");
            SqlCommand cmd5 = new SqlCommand(sql5, con);
            using (SqlDataReader dr = cmd5.ExecuteReader())
            {
                if (dr.Read())
                {
                    dailyfarmer_namelabel.Text = dr["name"].ToString();
                    dailyfarmer_pricelabel.Text = dr["price"].ToString();
                }
            }


        }

        private void addjuhayna_Click(object sender, EventArgs e)  //adding juhayna to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", juhayna_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void addnido_Click(object sender, EventArgs e)   //adding nido to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", nido_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void adddailyfarmer_Click(object sender, EventArgs e)  //adding daily farmer  to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", dailyfarmer_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void addalmarai_Click(object sender, EventArgs e)    //adding marsai to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", marai_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void addlactel_Click(object sender, EventArgs e)    //adding lactel to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", lactel_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void adddinafarms_Click(object sender, EventArgs e)    //adding dinafarms to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", dinafarms_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }
    }
}
