﻿namespace eventdriven_project
{
    partial class cheeseform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cheeseform));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.backlabel = new System.Windows.Forms.Label();
            this.nextlabel = new System.Windows.Forms.Label();
            this.exitlabel = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.kiri_namelabel = new System.Windows.Forms.Label();
            this.kiri_pricelabel = new System.Windows.Forms.Label();
            this.addkiri = new System.Windows.Forms.Button();
            this.teama_namelabel = new System.Windows.Forms.Label();
            this.teama_pricelabel = new System.Windows.Forms.Label();
            this.addteama = new System.Windows.Forms.Button();
            this.Domtycreamy_namelabel = new System.Windows.Forms.Label();
            this.domtycreamy_pricelabel = new System.Windows.Forms.Label();
            this.panda_namelabel = new System.Windows.Forms.Label();
            this.adddomtycreamy = new System.Windows.Forms.Button();
            this.panda_pricelabel = new System.Windows.Forms.Label();
            this.addpanda = new System.Windows.Forms.Button();
            this.roomy_namelabel = new System.Windows.Forms.Label();
            this.roomy_pricelabel = new System.Windows.Forms.Label();
            this.addroomy = new System.Windows.Forms.Button();
            this.mozarella_namelabel = new System.Windows.Forms.Label();
            this.mozarella_pricelabel = new System.Windows.Forms.Label();
            this.addmozarella = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(549, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(285, 41);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cheese Products";
            // 
            // backlabel
            // 
            this.backlabel.AutoSize = true;
            this.backlabel.Font = new System.Drawing.Font("Bookman Old Style", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backlabel.Location = new System.Drawing.Point(354, 27);
            this.backlabel.Name = "backlabel";
            this.backlabel.Size = new System.Drawing.Size(49, 20);
            this.backlabel.TabIndex = 2;
            this.backlabel.Text = "<<<<";
            this.backlabel.Click += new System.EventHandler(this.backlabel_Click);
            // 
            // nextlabel
            // 
            this.nextlabel.AutoSize = true;
            this.nextlabel.Font = new System.Drawing.Font("Bookman Old Style", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nextlabel.Location = new System.Drawing.Point(979, 23);
            this.nextlabel.Name = "nextlabel";
            this.nextlabel.Size = new System.Drawing.Size(49, 20);
            this.nextlabel.TabIndex = 3;
            this.nextlabel.Text = ">>>>";
            this.nextlabel.Click += new System.EventHandler(this.nextlabel_Click);
            // 
            // exitlabel
            // 
            this.exitlabel.AutoSize = true;
            this.exitlabel.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitlabel.Location = new System.Drawing.Point(1300, 9);
            this.exitlabel.Name = "exitlabel";
            this.exitlabel.Size = new System.Drawing.Size(27, 28);
            this.exitlabel.TabIndex = 4;
            this.exitlabel.Text = "x";
            this.exitlabel.Click += new System.EventHandler(this.exitlabel_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(156, 94);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(220, 164);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(556, 94);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(220, 164);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(983, 94);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(220, 164);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 7;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(156, 468);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(220, 164);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 8;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(567, 468);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(220, 164);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 9;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(983, 457);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(220, 164);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 10;
            this.pictureBox7.TabStop = false;
            // 
            // kiri_namelabel
            // 
            this.kiri_namelabel.AutoSize = true;
            this.kiri_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kiri_namelabel.Location = new System.Drawing.Point(231, 267);
            this.kiri_namelabel.Name = "kiri_namelabel";
            this.kiri_namelabel.Size = new System.Drawing.Size(92, 33);
            this.kiri_namelabel.TabIndex = 11;
            this.kiri_namelabel.Text = "Name";
            // 
            // kiri_pricelabel
            // 
            this.kiri_pricelabel.AutoSize = true;
            this.kiri_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kiri_pricelabel.Location = new System.Drawing.Point(231, 308);
            this.kiri_pricelabel.Name = "kiri_pricelabel";
            this.kiri_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.kiri_pricelabel.TabIndex = 12;
            this.kiri_pricelabel.Text = "Price";
            // 
            // addkiri
            // 
            this.addkiri.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addkiri.ForeColor = System.Drawing.Color.DarkGreen;
            this.addkiri.Location = new System.Drawing.Point(198, 350);
            this.addkiri.Name = "addkiri";
            this.addkiri.Size = new System.Drawing.Size(157, 35);
            this.addkiri.TabIndex = 13;
            this.addkiri.Text = "Add To Cart";
            this.addkiri.UseVisualStyleBackColor = true;
            this.addkiri.Click += new System.EventHandler(this.addkiri_Click);
            // 
            // teama_namelabel
            // 
            this.teama_namelabel.AutoSize = true;
            this.teama_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teama_namelabel.Location = new System.Drawing.Point(624, 267);
            this.teama_namelabel.Name = "teama_namelabel";
            this.teama_namelabel.Size = new System.Drawing.Size(92, 33);
            this.teama_namelabel.TabIndex = 14;
            this.teama_namelabel.Text = "Name";
            // 
            // teama_pricelabel
            // 
            this.teama_pricelabel.AutoSize = true;
            this.teama_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teama_pricelabel.Location = new System.Drawing.Point(624, 300);
            this.teama_pricelabel.Name = "teama_pricelabel";
            this.teama_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.teama_pricelabel.TabIndex = 15;
            this.teama_pricelabel.Text = "Price";
            // 
            // addteama
            // 
            this.addteama.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addteama.ForeColor = System.Drawing.Color.DarkGreen;
            this.addteama.Location = new System.Drawing.Point(597, 350);
            this.addteama.Name = "addteama";
            this.addteama.Size = new System.Drawing.Size(157, 35);
            this.addteama.TabIndex = 16;
            this.addteama.Text = "Add To Cart";
            this.addteama.UseVisualStyleBackColor = true;
            this.addteama.Click += new System.EventHandler(this.addteama_Click);
            // 
            // Domtycreamy_namelabel
            // 
            this.Domtycreamy_namelabel.AutoSize = true;
            this.Domtycreamy_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Domtycreamy_namelabel.Location = new System.Drawing.Point(1053, 267);
            this.Domtycreamy_namelabel.Name = "Domtycreamy_namelabel";
            this.Domtycreamy_namelabel.Size = new System.Drawing.Size(92, 33);
            this.Domtycreamy_namelabel.TabIndex = 17;
            this.Domtycreamy_namelabel.Text = "Name";
            // 
            // domtycreamy_pricelabel
            // 
            this.domtycreamy_pricelabel.AutoSize = true;
            this.domtycreamy_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.domtycreamy_pricelabel.Location = new System.Drawing.Point(1053, 300);
            this.domtycreamy_pricelabel.Name = "domtycreamy_pricelabel";
            this.domtycreamy_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.domtycreamy_pricelabel.TabIndex = 18;
            this.domtycreamy_pricelabel.Text = "Price";
            // 
            // panda_namelabel
            // 
            this.panda_namelabel.AutoSize = true;
            this.panda_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panda_namelabel.Location = new System.Drawing.Point(220, 635);
            this.panda_namelabel.Name = "panda_namelabel";
            this.panda_namelabel.Size = new System.Drawing.Size(92, 33);
            this.panda_namelabel.TabIndex = 19;
            this.panda_namelabel.Text = "Name";
            // 
            // adddomtycreamy
            // 
            this.adddomtycreamy.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adddomtycreamy.ForeColor = System.Drawing.Color.DarkGreen;
            this.adddomtycreamy.Location = new System.Drawing.Point(1019, 350);
            this.adddomtycreamy.Name = "adddomtycreamy";
            this.adddomtycreamy.Size = new System.Drawing.Size(157, 35);
            this.adddomtycreamy.TabIndex = 20;
            this.adddomtycreamy.Text = "Add To Cart";
            this.adddomtycreamy.UseVisualStyleBackColor = true;
            this.adddomtycreamy.Click += new System.EventHandler(this.adddomtycreamy_Click);
            // 
            // panda_pricelabel
            // 
            this.panda_pricelabel.AutoSize = true;
            this.panda_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panda_pricelabel.Location = new System.Drawing.Point(231, 668);
            this.panda_pricelabel.Name = "panda_pricelabel";
            this.panda_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.panda_pricelabel.TabIndex = 21;
            this.panda_pricelabel.Text = "Price";
            // 
            // addpanda
            // 
            this.addpanda.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addpanda.ForeColor = System.Drawing.Color.DarkGreen;
            this.addpanda.Location = new System.Drawing.Point(198, 702);
            this.addpanda.Name = "addpanda";
            this.addpanda.Size = new System.Drawing.Size(157, 35);
            this.addpanda.TabIndex = 22;
            this.addpanda.Text = "Add To Cart";
            this.addpanda.UseVisualStyleBackColor = true;
            this.addpanda.Click += new System.EventHandler(this.addpanda_Click);
            // 
            // roomy_namelabel
            // 
            this.roomy_namelabel.AutoSize = true;
            this.roomy_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roomy_namelabel.Location = new System.Drawing.Point(634, 635);
            this.roomy_namelabel.Name = "roomy_namelabel";
            this.roomy_namelabel.Size = new System.Drawing.Size(92, 33);
            this.roomy_namelabel.TabIndex = 23;
            this.roomy_namelabel.Text = "Name";
            // 
            // roomy_pricelabel
            // 
            this.roomy_pricelabel.AutoSize = true;
            this.roomy_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roomy_pricelabel.Location = new System.Drawing.Point(645, 664);
            this.roomy_pricelabel.Name = "roomy_pricelabel";
            this.roomy_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.roomy_pricelabel.TabIndex = 24;
            this.roomy_pricelabel.Text = "Price";
            // 
            // addroomy
            // 
            this.addroomy.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addroomy.ForeColor = System.Drawing.Color.DarkGreen;
            this.addroomy.Location = new System.Drawing.Point(597, 700);
            this.addroomy.Name = "addroomy";
            this.addroomy.Size = new System.Drawing.Size(157, 35);
            this.addroomy.TabIndex = 25;
            this.addroomy.Text = "Add To Cart";
            this.addroomy.UseVisualStyleBackColor = true;
            this.addroomy.Click += new System.EventHandler(this.addroomy_Click);
            // 
            // mozarella_namelabel
            // 
            this.mozarella_namelabel.AutoSize = true;
            this.mozarella_namelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mozarella_namelabel.Location = new System.Drawing.Point(1053, 635);
            this.mozarella_namelabel.Name = "mozarella_namelabel";
            this.mozarella_namelabel.Size = new System.Drawing.Size(92, 33);
            this.mozarella_namelabel.TabIndex = 26;
            this.mozarella_namelabel.Text = "Name";
            // 
            // mozarella_pricelabel
            // 
            this.mozarella_pricelabel.AutoSize = true;
            this.mozarella_pricelabel.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mozarella_pricelabel.Location = new System.Drawing.Point(1064, 668);
            this.mozarella_pricelabel.Name = "mozarella_pricelabel";
            this.mozarella_pricelabel.Size = new System.Drawing.Size(81, 33);
            this.mozarella_pricelabel.TabIndex = 27;
            this.mozarella_pricelabel.Text = "Price";
            // 
            // addmozarella
            // 
            this.addmozarella.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addmozarella.ForeColor = System.Drawing.Color.DarkGreen;
            this.addmozarella.Location = new System.Drawing.Point(1046, 702);
            this.addmozarella.Name = "addmozarella";
            this.addmozarella.Size = new System.Drawing.Size(157, 35);
            this.addmozarella.TabIndex = 28;
            this.addmozarella.Text = "Add To Cart";
            this.addmozarella.UseVisualStyleBackColor = true;
            this.addmozarella.Click += new System.EventHandler(this.addmozarella_Click);
            // 
            // cheeseform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(1339, 765);
            this.Controls.Add(this.addmozarella);
            this.Controls.Add(this.mozarella_pricelabel);
            this.Controls.Add(this.mozarella_namelabel);
            this.Controls.Add(this.addroomy);
            this.Controls.Add(this.roomy_pricelabel);
            this.Controls.Add(this.roomy_namelabel);
            this.Controls.Add(this.addpanda);
            this.Controls.Add(this.panda_pricelabel);
            this.Controls.Add(this.adddomtycreamy);
            this.Controls.Add(this.panda_namelabel);
            this.Controls.Add(this.domtycreamy_pricelabel);
            this.Controls.Add(this.Domtycreamy_namelabel);
            this.Controls.Add(this.addteama);
            this.Controls.Add(this.teama_pricelabel);
            this.Controls.Add(this.teama_namelabel);
            this.Controls.Add(this.addkiri);
            this.Controls.Add(this.kiri_pricelabel);
            this.Controls.Add(this.kiri_namelabel);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.exitlabel);
            this.Controls.Add(this.nextlabel);
            this.Controls.Add(this.backlabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "cheeseform";
            this.Text = "cheeseform";
            this.Load += new System.EventHandler(this.cheeseform_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label backlabel;
        private System.Windows.Forms.Label nextlabel;
        private System.Windows.Forms.Label exitlabel;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label kiri_namelabel;
        private System.Windows.Forms.Label kiri_pricelabel;
        private System.Windows.Forms.Button addkiri;
        private System.Windows.Forms.Label teama_namelabel;
        private System.Windows.Forms.Label teama_pricelabel;
        private System.Windows.Forms.Button addteama;
        private System.Windows.Forms.Label Domtycreamy_namelabel;
        private System.Windows.Forms.Label domtycreamy_pricelabel;
        private System.Windows.Forms.Label panda_namelabel;
        private System.Windows.Forms.Button adddomtycreamy;
        private System.Windows.Forms.Label panda_pricelabel;
        private System.Windows.Forms.Button addpanda;
        private System.Windows.Forms.Label roomy_namelabel;
        private System.Windows.Forms.Label roomy_pricelabel;
        private System.Windows.Forms.Button addroomy;
        private System.Windows.Forms.Label mozarella_namelabel;
        private System.Windows.Forms.Label mozarella_pricelabel;
        private System.Windows.Forms.Button addmozarella;
    }
}