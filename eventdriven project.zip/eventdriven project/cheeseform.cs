﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eventdriven_project
{
    public partial class cheeseform : Form
    {
        public cheeseform()
        {
            InitializeComponent();
        }

        private void backlabel_Click(object sender, EventArgs e)  //back to previous
        {
            Categories_form m1 = new Categories_form();
            m1.Show();
            this.Hide();
        }

        private void nextlabel_Click(object sender, EventArgs e)   //sending user to invoice form
        {
            invoiceform f1 = new invoiceform();
            f1.Show();
            this.Hide();
        }

        private void exitlabel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //connection string for connecting our project with server in order to access tables in database

        SqlConnection con = new SqlConnection("Data Source=DESKTOP-2QL2JJ3\\SQLEXPRESS01;Initial Catalog=supermarketdatabase;Integrated Security=True");
        private void cheeseform_Load(object sender, EventArgs e)
        {
            //kiri info from database

            string sql = ("SELECT * FROM  [cheesetable] WHERE parcode='po987'");    //queuring by using select
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            using (SqlDataReader dr = cmd.ExecuteReader())
            {
                if (dr.Read())
                {
                    //putting data of feild name in kiri namelabel in form
                    //putting data of feild price in kiri pricelabel in form

                    kiri_namelabel.Text = dr["name"].ToString();
                    kiri_pricelabel.Text = dr["price"].ToString();
                }

            }

            //Teama info from database 

            string sql1 = ("SELECT * FROM  [cheesetable] WHERE parcode='9bgcb'");    //queuring by using select
            SqlCommand cmd1 = new SqlCommand(sql1, con);
            using (SqlDataReader dr = cmd1.ExecuteReader())
            {
                if (dr.Read())
                {

                    teama_namelabel.Text = dr["name"].ToString();
                    teama_pricelabel.Text = dr["price"].ToString();
                }

            }

            //Domty info from database

            string sql2 = ("SELECT * FROM  [cheesetable] WHERE parcode='uvred'");
            SqlCommand cmd2 = new SqlCommand(sql2, con);
            using (SqlDataReader dr = cmd2.ExecuteReader())
            {
                if (dr.Read())
                {

                    Domtycreamy_namelabel.Text = dr["name"].ToString();
                    domtycreamy_pricelabel.Text = dr["price"].ToString();
                }

            }

            //panda info from database

            string sql3 = ("SELECT * FROM  [cheesetable] WHERE parcode='87yhre'");
            SqlCommand cmd3 = new SqlCommand(sql3, con);
            using (SqlDataReader dr = cmd3.ExecuteReader())
            {
                if (dr.Read())
                {

                    panda_namelabel.Text = dr["name"].ToString();
                    panda_pricelabel.Text = dr["price"].ToString();
                }

            }

            //roomy info from database


            string sql4 = ("SELECT * FROM  [cheesetable] WHERE parcode='yhgt54'");
            SqlCommand cmd4 = new SqlCommand(sql4, con);
            using (SqlDataReader dr = cmd4.ExecuteReader())
            {
                if (dr.Read())
                {

                    roomy_namelabel.Text = dr["name"].ToString();
                    roomy_pricelabel.Text = dr["price"].ToString();
                }

            }


            //mozarella info from database


            string sql5 = ("SELECT * FROM  [cheesetable] WHERE parcode='87uhfc'");
            SqlCommand cmd5 = new SqlCommand(sql5, con);
            using (SqlDataReader dr = cmd5.ExecuteReader())
            {
                if (dr.Read())
                {

                    mozarella_namelabel.Text = dr["name"].ToString();
                    mozarella_pricelabel.Text = dr["price"].ToString();
                }

            }


        }

        private void addkiri_Click(object sender, EventArgs e)    //adding kiri to cart
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", kiri_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void addteama_Click(object sender, EventArgs e)   //adding teama to cart
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", teama_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void adddomtycreamy_Click(object sender, EventArgs e)   //adding domty to receipt and cart
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", domtycreamy_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void addpanda_Click(object sender, EventArgs e)      //adding panda to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", domtycreamy_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void addroomy_Click(object sender, EventArgs e)    //adding roomy to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price",roomy_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        private void addmozarella_Click(object sender, EventArgs e)   //adding mozarella to receipt
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[totalpricetable] VALUES(@price)", con);
            cmd.Parameters.AddWithValue("@price", mozarella_pricelabel.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }
    }
}
